﻿<#
.SYNOPSIS
    Version 4.0 de el script de instalacion de DMS de Quiter

.DESCRIPTION
    descarga, instala y utiliza el modulo Qsislib.psm1 de quiter
    para llevar a cabo la instalacion 
    
.NOTES
    Author      : Quiter Sistemas
    Owner       : Quiter-SC S.L.
    Version 1   : 11/2017 
    Version 2   : 09/01/2020
    Version 3   : 01/03/2020
    Version 4   : 20/07/2020  
	Version 5   : 17/01/2021
	Version 6   : 14/04/2021
	Version 7   : 03/02/2022
#>

# --
# Inicializamos el log, y declaramos que no queremos errores en la pantalla
# --

#$VerbosePreference = "Continue"
$VerbosePreference = 'SilentlyContinue'
# $DebugPreference = "con" no por el momento
$ErrorActionPreference = "Continue" # si existen errores que no rompa el script
Set-Location $PSScriptRoot          # nos movemos a la ubicacion del script
$global:logname = New-Item -Path ("logs\QsisDmsInstall_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File #log sencillo 
$global:script_pos = $PSScriptRoot
$global:cod_cliente=""
$PSVersion = Get-Host | Select-Object Version

## Importamos los modulos comunes y el modulo nuestro.

    try{
        
        Import-Module BitsTransfer
        Import-Module servermanager
        Import-Module ScheduledTasks
        Import-Module .\resources\Qsislib.psm1
            
    }catch{
        
         Write-host "Un modulo no se pudo instalar.. [X] ABORTANDO INSTLALACION [X]" -ForegroundColor Red
    }         
    
# --
# Función necesaria para tomar de nuevo las config de la libreria, muy util para el desarrollo del script 
# --

    function Recargar_Modulo_(){
        
        Set-Location $script_pos
        Write-Host "Recargando Módulo"
        Write-Host ""
        Remove-Module -Name Qsislib 
        Import-Module -Name ".\resources\Qsislib.psm1"
        #sleep 1 # para que se vea por pantalla que se recarga, si no va muy rapido
        
    }

    function load_help(){
            
        $help = ".\resources\guide\BASICS.txt"     
        $text = Get-Content $help | Out-String   
        Write-Host $text 
        $next = Read-Host "[ENTER TO EXIT]"
       
    }

################## Menú Principal ###################

verificar_admin
formulario

$escierto = 1
while($escierto){
 
        #cls
        Set-Location $PSScriptRoot
        cabecera
        Write-Host $text 
        Write-host "+--------------------------------------------+"
        Write-Host "Qsis ToolKit DMS"
        Write-Host "Last update -> 17/01/2020"
        Write-Host "sac.sistemas@quiter-sc.com"
	    Write-Host ""
        Write-Host "Login as:" $global:identidad.Identities.Name
        Write-Host "Root dir:" $PSScriptRoot
        Write-Host "PS ver..:" $PSVersion
		Write-Host "PS lang.:" $PSCulture
		Write-Host "UI lang.:" $PSUICulture
        pre_check
        Write-Host ""
        Write-Host "Valores Parámetros"
        testvar
        Write-Host " ________M_E_N_U_____O_P_C_I_O_N_E_S________ "
        Write-Host "|  [1] - Instalar  DMS                      |" -BackgroundColor DarkCyan  
        Write-Host "|  [2] - Modificar Parámetros               |"   
        Write-Host "|  [3] - Recargar  Módulo                   |" -BackgroundColor DarkCyan
        Write-Host "|  [4] - Firewall  Manual                   |" 
        Write-Host "|  [5] - Guía?                              |" -BackgroundColor DarkCyan
        Write-Host "|  [q] - Salir                              |" 
        Write-Host "|___________________________________________|"
        #Write-Host "   X - test "

        $eleccion = Read-Host ">>>> Introduce opción [1-6] "
        switch($eleccion){

            1{menu_instalacion}
            2{menu_Modif__Var_}
            3{Recargar_Modulo_}
            5{menu_FirewalMain}
            6{load_help}
            q{exit}
            ps{powershell.exe}
        
        }

}
