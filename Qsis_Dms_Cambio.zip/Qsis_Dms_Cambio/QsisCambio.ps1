
function RsyncRoboCopy(){
# ACTIVAR/DESACTIVAR SMB1
#Get-WindowsFeature FS-SMB1
#Enable-WindowsOptionalFeature -Online -FeatureName smb1protocol   >> Reiniciar
#Disable-WindowsOptionalFeature -Online -FeatureName smb1protocol  >> Reiniciar
# ROBOCOPY
#RoboCopy \\192.168.4.250\Q$\quiter\CONEXION q:\instalaciones\Qsis_Dms_Cambio\quiter\CONEXION /E /COPYALL /SEC /MIR /R:2 /W:2 /V /FP /LOG:q:\instalaciones\cambio.202103\RoboCopy.log
#RoboCopy \\192.168.4.150\Q$\quiter.NO.BORRAR q:\instalaciones\Qsis_Dms_Cambio\quiter.NO.BORRAR /E /COPYALL /SEC /MIR /R:2 /W:2 /V /FP /LOG:q:\instalaciones\cambio.202103\RoboCopy_Quiter.NO.BORRAR_20210329_1412.log
# NET USE
#net use recurso contrase�a /USER:dominio\usuario
# UVBACKUP
#cambia todos los ficheros, desprogramar para que robocopy copie solo los ficheros modificados por la actividad de los usuarios

$RoboCopyLog = New-Item -Path ("$PSScriptRoot\QsisRoboCopy___{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
$DmsNewQdir  = $PSScriptRoot+'\quiter'
$DmsOldQdir  = '\\192.168.50.12\Q$\quiter'
$DmsOldUser  = 'DOMINIO\usuario'
$DmsOldPass  = 'ecnlsnd'
net use $DmsOldQdir $DmsOldPass /USER:$DmsOldUser
net use
RoboCopy $DmsOldQdir $DmsNewQdir /E /COPYALL /SEC /MIR /R:2 /W:2 /V /FP /LOG:$RoboCopyLog
}

function Proc_UniVerse(){
$UvLog = New-Item -Path ("$PSScriptRoot\QsisUvProces___{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
$UvCmd = $PSScriptRoot+'\QsisGen4glCmd.txt'
$UvExe = "c:\uv\uv\bin\uv <$UvCmd 1>$UvLog"
q:
Set-Location Q:\quiter\GEN4GL
cmd.exe /c "$UvExe"
cd $PSScriptRoot
Copy-Item Q:\quiter.plat\qjava\libs\Universe\11.3.2 -Destination Q:\quiter\qjava\libs\Universe -Recurse
Move-Item -Path Q:\quiter\qjava\conf\quitergateway.properties -Destination Q:\quiter\qjava\conf\quitergateway.properties.bak
Copy-Item Q:\instalaciones\Qsis_Dms_Cambio\new_QGW\quitergateway.properties -Destination Q:\quiter\qjava\conf\quitergateway.properties
Move-Item -Path Q:\quiter\QDBLiveWin -Destination Q:\quiter\QDBLiveWin.old
Copy-Item Q:\quiter.plat\QDBLiveWin -Destination Q:\quiter\QDBLiveWin -Recurse
Move-Item -Path Q:\quiter\bin -Destination Q:\quiter\bin.old
Copy-Item Q:\quiter.plat\bin -Destination Q:\quiter\bin -Recurse
Q:\instalaciones\Qsis_Dms_Cambio\QsisPermisos.bat

}

#Paso-1 rsync de quiter
###RsyncRoboCopy

#Paso-2 mover a mano quiter a q:

#Paso-3 procesos UniVerse (qsis.prepbatch, update account, triggers, par_gen, ftp user)
###Proc_UniVerse

#Paso-4 QGW usuario gateway, librerias, verificar que arranca

