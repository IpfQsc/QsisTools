# --------------------
#  ��  ATENCION !!
#  
#  SI ENCUENTRAS ALGUN BUG, FALLO, MALA CONFIGURACION O SI TIENES DUDAS SOBRE ESTE SCRIPT   
#  REPORTALO EN sac.sistemas@quiter-sc.com CON EL TITULO [BUG | DUDA | FALLO | BADCONF + SCRIPT]
#  GRACIAS 
#    
# -------------------
#

#Lanzamos la transcripcion
$global:tiempo         = Get-Date
Start-Transcript ("logs\All_Commands___{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) #Log literal/transcription
$VerbosePreference     = 'SilentlyContinue'

#  1- Variables globales
# --
#  Es necesario que estas variables globales esten aqui para que as� sean accesibles desde cualquier funcion del codigo
#  sin tener que pasarlos como argumento, simplificando el funcionamiento de este kit de herramientas para el Administrador de sistenas de quiter
#  Las opciones aqui hard-codeadas ser�n las default, si es necesario modificar la unidad destino, desde el menu hay opcion, pero se puede cambiar aqui
# --

$global:UvHome         = 'c:\uv\uv'
$global:universe_ver   = '11.3.4' 
$global:codigo_pais    = 'ES'
$global:cod_cliente    = '1234'
$global:target         = 'Q' 
$global:QuiterUnit     = $target+':'
$global:inst           = '\instalaciones'
$global:QuiterInst     = $QuiterUnit+$inst
$global:QuiterRepo     = $QuiterInst+'\RepoWin'
$global:QuiterSetupDir = $QuiterInst+'\quitersetup'
$global:QuiterDir      = $QuiterUnit+'\quiter'
$global:QSetupQDir     = $target+'\:\\quiter'
$global:QSetupDir      = $target+'\:\'+$inst+'\\quitersetup'
$global:Diripv4        = (Test-Connection -ComputerName $env:ComputerName -Count 1).IPV4Address.IPAddressToString
#$global:VOpenVPN="OpenVPN-2.5.0-I601-amd64.msi" 
$global:VOpenVPN       = "OpenVPN-2.5.5-I602-amd64.msi"
# Variable Versi�n Windows
$WIN_VERSION = (Get-WmiObject win32_operatingsystem) | % caption | % split '' 6 | select -First 4 | select -Last 1

# 2- Tablas Hash
# --
#  tablas para el sistema de control errores
#  tablas para configurar Qjava y Web por paises
# --

# Hash tables para el sistema de control errores
$flags_errors = @{ 

        # --
        # IDEA: hacer un re build de los flagErrors pero dividido por funciones y que se contrulla en runtime
        # si hay un error que se apunte el nombre de la funcion y se a�ada/intente a�adir ese error especifico/contemplado, en caso
        # contrario que se anote como error desconocido.


		"ERROR_crear_directorios" = 0
        "ERROR_descarga_repo" = 0
        "ERROR_instalacion_OpenVpn" = 0
		"ERROR_existe_comando" = 0
        "ERROR_instalacion_universe" = 0
        "ERROR_instalacion_quiter_setup" = 0
        "ERROR_descomprimir" = 0
        "ERROR_discos_mal" = 0
        "ERROR_crear_usuarios" = 0
		"ERROR_crear_usuarios_ad" = 0
        "ERROR_dar_permisos" = 0
        "ERROR_despliegue_qjava" = 0
        "ERROR_despliegue_web" = 0
        "ERROR_desp_IIS" = 0
        "ERROR_comp_carpetas" = 0
        "ERROR_qibk" = 0
        "ERROR_qdblive" = 0
        "ERROR_QAW" = 0
        "ERROR_limpieza" = 0
        "ERROR_setup_rules" = 0
        "ERROR_manual_rules" = 0
        "ERROR_TELNET_NO_RESPONDE" = 0
        "ERROR_SSH_NO_RESPONDE" = 0
        "ERROR_SERVICIO_OPENVPN_NOACTIVO" = 0
        "ERROR_SERVICIO_QUITERGATEWAY_NOACTIVO" = 0
        "ERROR_SERVICIO_UVSLAVE_NOACTIVO" = 0
        "ERROR_SERVICIO_UVRPC_NOACTIVO" = 0
        "ERROR_SERVICIO_UNIVERSE_NOACTIVO" = 0
        "ERROR_SERVICIO_WEB_NOACTIVO" = 0
        "Nombres_archivos_no_descomp" = $Null


        "IsADEnable" = "$Null"
        "pre_check" = 0
    } # Hay cosas que retocar aqui
$UTILS        = @{
    
   PreCheck = 0
   IsAdEnable = $false

}
$QSERVICES    = @{

   #Errores de servicios
   TELNET_NO_RESPONDE = $false
   SSH_NO_RESPONDE = $false
   OPENVPN_NO_RESPONDE = $false
   QUITERGW_NO_RESPONDE = $false
   UNIVERSE_NO_RESPONDE = $false
   WEB_NO_RESPONDE = $false
   
   IsUnivereEnable = $false
   IsOpenVpnEnable = $false
   IsQuiterGWEnable = $false
   IsWebEnable = $false
   IsTelnetEnable = $false

}
$ERRORES      = @{

   #Errores pertenecientes a la instalacion
	CrearDirectorios = 0, "$NULL"
	DescargaRepositorio = 0 , "$NULL"
	OpenVpn = 0 , "$NULL"
	ExisteComando = 0, "$NULL"
	AddTap = 0 , "$NULL"
	Universe = 0 , "$NULL"
	CreaUsuarios = 0 , "$NULL"
	CreaUsuariosAD = 0, "$NULL"
	QuiterSetUp = 0 , "$NULL"
	QuiterWeb = 0 , "$NULL"
	Qjava = 0 , "$NULL"
	confIIS = 0 , "$NULL"
	CarpetasCompartidas = 0 , "$NULL"
	Qibk = 0 , "$NULL"
	Qdblive = 0 , "$NULL"
	QAW = 0 , "$NULL" 
	Descomprimir = 0 , "$NULL"
	NoDiscos = 0 , "$NULL"
	ReglasFirewall = 0, "$NULL"
	Limpieza = 0, "$NULL"
	FirewallConfig = 0, "$NULL"
 }
$FLAGS        = @{
    
    errores = $ERRORES
    utils = $UTILS
    servicios = $QSERVICES

}
# Hash tables para configurar Qjava y Web
$espa�a       = @{

    CodigoPais = "ES"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=ES;-Duser.country=ES;-Duser.timezone=Europa/Madrid;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$esagente     = @{

    CodigoPais = "AG"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=ES;-Duser.country=ES;-Duser.timezone=Europa/Madrid;-XX:+UseParallelGC;-Xmx2G;"
    selected = $false
}
$argentina    = @{

    CodigoPais = "ARG"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=AR;-Duser.country=AR;-Duser.timezone=America/Buenos_Aires;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$aragente     = @{

    CodigoPais = "AGARG"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=AR;-Duser.country=AR;-Duser.timezone=America/Buenos_Aires;-XX:+UseParallelGC;-Xmx2G;"
    selected = $false
}
$portugal     = @{

    CodigoPais = "PT"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=PT;-Duser.country=PT;-Duser.timezone=Europe/Lisbon;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$ptagente     = @{

    CodigoPais = "AGPT"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=PT;-Duser.country=PT;-Duser.timezone=Europe/Lisbon;-XX:+UseParallelGC;-Xmx2G;"
    selected = $false
}
$mexico       = @{
    
    CodigoPais = "MX"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=MX;-Duser.country=MX;-Duser.timezone=America/Mexico_City;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$colombia     = @{
    
    CodigoPais = "CO"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=CO;-Duser.country=CO;-Duser.timezone=America/Bogota;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$chile        = @{
    
    CodigoPais = "CL"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=CL;-Duser.country=CL;-Duser.timezone=America/Santiago;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$bolivia      = @{
    
    CodigoPais = "BL"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=BL;-Duser.country=BL;-Duser.timezone=America/La_Paz;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$peru         = @{
    
    CodigoPais = "PE"
    string = "SERV_JAVA_OPTS=-Duser.language=es;-Duser.region=PE;-Duser.country=PE;-Duser.timezone=America/Lima;-XX:+UseParallelGC;-Xmx4G;"
    selected = $false
}
$PAISES       = @{
     
    ES = $espa�a
    ESAG = $esagente
    AR = $argentina
    ARAG = $aragente
    PT = $portugal
    PTAG = $ptagente
    MX =  $mexico 
    CO = $colombia
    CL = $chile
    BL = $bolivia
    PE = $peru
    
}

# 3- Funciones
# --
#  Las funciones estan ordenadas intentando seguir un patron:
#      1� men�s para que se pueda seguir el flujo de la aplicaci�n.
#      2� funciones principales que instalan aplicaciones/servicios Quiter.
#      3� funciones que organizan, manejan y controlan el propio script.
# --

#-- Funciones Menus

function menu_instalacion(){
        
    a�adelog -message "MENU INSTALAR DMS" -msgtype "INFO " -func_name "begin"
    #Write-Host $FLAGS.utils.PreCheck
    $global:escierto = 1
    #Write-Host "A "$global:escierto
    #if($FLAGS.utils.PreCheck -le 0){pre_check}
    #pre_check
    #Write-Host "D " $global:escierto
    while($global:escierto){
        #cls
        cabecera
        Write-Host " ____M_E_N_U____I_N_S_T_A_L_A_R____D_M_S_____ "
        Write-Host "| [1] - Instalaci�n Completa Desatendida     |" -BackgroundColor DarkCyan  
        Write-Host "| [2] - Instalaci�n en 2 Fases               |" 
		Write-Host "| [3] - Instalaci�n Paso a Paso              |" -BackgroundColor DarkCyan
        Write-Host "| [4] - Check Logs                           |"    
        Write-Host "|                                            |" 
        Write-Host "| [q] - Salir                                |" -BackgroundColor DarkCyan  
        Write-Host "|____________________________________________|"
        $elige = Read-Host ">>>> Introduce opci�n [1-4] "
        switch($elige){
            1{"Instalacion Desatendida"; _instalacion_20_ ; a�adelog -message "Opci�n seleccionada Instalacion Completa   " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
            2{"Instalacion en 2 Fases "; menu_1repo_2plat ; a�adelog -message "Opci�n seleccionada Instalacion en 2 Fases " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
			3{"Instalaci�n Paso a Paso"; menu_paso_a_paso ; a�adelog -message "Opci�n seleccionada Instalacion Paso a Paso" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
            4{"Check Logs!            "; check_logs       ; a�adelog -message "Opci�n seleccionada Check Logs             " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
            q{"";$global:escierto = 0}
        }
    }
    a�adelog -message "MENU INSTALAR DMS" -msgtype "INFO " -func_name "end  "
}
function menu_paso_a_paso(){
        
        a�adelog -message "*** INSTALACION PASO A PASO" -msgtype "INFO " -func_name "begin"
          
    
            $istrue = $true
            while($istrue){

                cabecera
                Write-host " __I_N_S_T_A_L_A_C_I_�_N___P_A_S_O_a_P_A_S_O___ "
                Write-Host "|  [1] - Descargar RepoWin                     |" -BackgroundColor DarkCyan  
                Write-Host "|  [2] - Descargar OpenVpn                     |"
                Write-Host "|  [3] - Creaci�n  Directorios                 |" -BackgroundColor DarkCyan 
                Write-Host "|  [4] - Creaci�n  Usuarios                    |" 			
				Write-Host "|  [5] - Instalar  OpenVpn                     |" -BackgroundColor DarkCyan 
                Write-Host "|  [6] - Instalar  Universe                    |" 
                Write-Host "|  [7] - Desplegar Permisos                    |" -BackgroundColor DarkCyan
                Write-Host "|  [8] - Desplegar QuiterSetup                 |" 
                Write-Host "|  [9] - Desplegar P�ginas Web                 |" -BackgroundColor DarkCyan
                Write-Host "| [10] - Desplegar Qjava                       |"  
                Write-Host "| [11] - Configura IIS                         |" -BackgroundColor DarkCyan
                Write-Host "| [12] - Compartir Carpetas                    |"  
                Write-Host "| [13] - Desplegar QIBK                        |" -BackgroundColor DarkCyan
                Write-Host "| [14] - Desplegar QDBLive                     |"  
                Write-Host "| [15] - Desplegar QAW                         |" -BackgroundColor DarkCyan
                Write-Host "| [16] - Configura directorios adicionales     |"  
				Write-Host "| [17] - Configura Firewall                    |" -BackgroundColor DarkCyan
				Write-Host "| [18] - DesActiva Netbios sobre tcp/ip        |"  
				Write-Host "| [19] - Hablitar  Escritorio Remoto           |" -BackgroundColor DarkCyan
				Write-Host "| [20] - Limpieza                              |"  
				Write-Host "| [21] - Cambiar perfil interfaces vpn + 18/20 |" -BackgroundColor DarkCyan 
                Write-Host "|  [+] - Mas                                   |" 
                Write-Host "|  [q] - Salir                                 |" -BackgroundColor DarkCyan 
                Write-Host "|______________________________________________|" 
                $manual = Read-Host ">>>> Introduce opci�n [1-20] "

                switch($manual){
    
					1{ _Descargar_RepoWin_ ; a�adelog -message "OPCION ELEGIDA 'Descarga RepoWin'                  " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
					
					2{ _Descargar_OpenVpn_ ; a�adelog -message "OPCION ELEGIDA 'Descarga OpenVpn'                  " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
					
                    3{ _Crear_Directorios_ ; a�adelog -message "OPCION ELEGIDA 'Crea Directorios'                  " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                    4{ if($FLAGS.utils.IsADEnable -eq $true){
                          #Write-Host "CreaUsuarios AD"
                          #Write-Host $FLAGS.utils.IsADEnable
                          _Crear_Usuarios_AD_ ; a�adelog -message "OPCION ELEGIDA 'Crear usuarios AD'              " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name                   
                       }
                       else{
                          #Write-Host "CreaUsuarios LS"
                          #Write-Host $FLAGS.utils.IsADEnable
                          _Crear_Usuarios_LS_ ; a�adelog -message "OPCION ELEGIDA 'Crear usuarios LS'              " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name                   
                       }
                    }

                    5{ _Instalar_OpenVpn__ ; a�adelog -message "OPCION ELEGIDA 'Instala OpenVpn '                  " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                    6{ _Instalar_UniVerse_ ; a�adelog -message "OPCION ELEGIDA 'Instala Universe'                  " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

				    7{ _Exe__QsisPermisos_ ; a�adelog -message "OPCION ELEGIDA 'Lanza permisos (via batch)'        " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                    8{ _Exe__QuiterSetup__ ; a�adelog -message "OPCION ELEGIDA 'Instala Quiter SetUp'              " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                    9{ _Desplegar_WebPage_ ; a�adelog -message "OPCION ELEGIDA 'despliega web'                     " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                   10{ _Instalar_QGateway_ ; a�adelog -message "OPCION ELEGIDA 'Despliega QAW'                     " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                   11{ _InstalConfig__IIS_ ; a�adelog -message "OPCION ELEGIDA 'configura iis'                     " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
				   
                   12{ _Compartir_Dir_____ ; a�adelog -message "OPCION ELEGIDA 'Compartir carpetas'                " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                   13{ _Desplegar_Qibk____ ; a�adelog -message "OPCION ELEGIDA 'Despliega qibk'                    " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                   14{ _Desplegar_QDBLive_ ; a�adelog -message "OPCION ELEGIDA 'Despliega QDBLive'                 " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

                   15{ _Desplegar_QawCli__ ; a�adelog -message "OPCION ELEGIDA 'Despliega QAW'                     " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name} 

                   16{ _Configurar_Dir____ ; a�adelog -message "OPCION ELEGIDA 'Configurar directorios adicionales'" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
				   
				   17{ _Configurar_FireW__ ; a�adelog -message "OPCION ELEGIDA 'Configuraci�n Firewall'            " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
				   
				   18{ _DesActivarNetBios_ ; a�adelog -message "OPCION ELEGIDA 'Deshabilitar Netbios sobre tcp/ip' " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

				   19{ _Activar__RDesktop_ ; a�adelog -message "OPCION ELEGIDA 'Hablitar escritorio remoto '       " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

				   20{ _Limpieza_TmpFiles_ ; a�adelog -message "OPCION ELEGIDA 'Limpieza'                          " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

				   21{ _Configurar_TunVpn_ ; a�adelog -message "OPCION ELEGIDA 'Cambiar perfil interfaces vpn y Deshabilitar Netbios sobre tcp/ip' " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
               
                   +{menu_pasoapaso_2}
                   q{" " ; $istrue = $false}
                   ps{powershell.exe}
                   42{cuarenta_y_dos}
                   defautl{"Necesitas seleccionar una opcion valida.. por favor, piensa"}
                }
            }

        a�adelog -message "*** INSTALACION PASO A PASO" -msgtype "INFO " -func_name "end  "
}
function menu_1repo_2plat(){
        
        a�adelog -message "*** INSTALACION 1�REPOWIN 2�PLATAFORMADO" -msgtype "INFO " -func_name "begin"
    
            $istrue = $true
            while($istrue){
                cabecera
                Write-host " __I_N_S_T_A_L_A_C_I_�_N____E_N___2___F_A_S_E_S__ "
                Write-Host "| [1] - Descarga RepoWin (GoogleDrive)  [1/20]   |" -BackgroundColor DarkCyan  
                Write-Host "| [2] - Instalaci�n Desatendida         [2-20]   |"
                Write-Host "|                                                |" 
				Write-Host "| [q] - Salir                                    |" -BackgroundColor DarkCyan 
                Write-Host "|________________________________________________|" 
                $manual = Read-Host ">>>> Introduce opci�n [1-2] "
                switch($manual){
					1{ _Descargar_RepoWin_ ; a�adelog -message "OPCION ELEGIDA 'Descarga RepoWin (GoogleDrive) [1/20] ' " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
                    2{ _instalacion_19_    ; a�adelog -message "OPCION ELEGIDA 'Instalaci�n Desatendida        [2-20] ' " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
					q{" " ; $istrue = $false}
					defautl{"Necesitas seleccionar una opcion valida.. por favor, piensa"}
                }
            }

        a�adelog -message "*** INSTALACION 1�REPOWIN 2�PLATAFORMADO" -msgtype "INFO " -func_name "end  "
}
function menu_pasoapaso_2(){
   
    $istrue = $true
    while($istrue){

		Write-host " __I_N_S_T_A_L_A_C_I_�_N____P_A_S_O_a_P_A_S_O__ "
        Write-Host "| [1] -  Revisar Permisos                      |" -BackgroundColor DarkCyan  
        Write-Host "| [2] -  A�ade nuevo tap                       |"
        Write-Host "| [3] -  A�ade regla firewall                  |" -BackgroundColor DarkCyan  
        Write-Host "| [4] -  Checkea logs                          |"
        Write-Host "|                                              |"
        Write-Host "| [5] -  M�s proximamente                      |" -BackgroundColor DarkCyan  
        Write-Host "| [6] -                                        |"
        Write-Host "| [7] -                                        |"
        Write-Host "| [8] -                                        |"
        Write-Host "| [q] -  Salir                                 |" -BackgroundColor DarkCyan  
        Write-Host "|______________________________________________|" 
        $manual = Read-Host ">>>> Introduce opci�n [1-5] "

        switch($manual){
        
            1{revisa_permisos ; a�adelog -message "OPCION ELEGIDA 'revisar permisos'" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name }
            2{add_tap; a�adelog -message "OPCION ELEGIDA 'A�adir adaptador'" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name }
            3{add_regla ; a�adelog -message "OPCION ELEGIDA 'A�adir regla firewall manual'" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name }
            4{}
            5{}
            6{}
            7{}
            8{"Esta opcion esta desactivada por seguridad" ; sleep 1}
            9{a�adelog -message "OPCION ELEGIDA 'a�adir adaptador'" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
            q{" " ; $istrue = $false}
        }

    }
}
function menu_FirewalMain(){

    a�adelog -message "INICIANDO MENU CONTROLADOR DE FIREWALL" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name

    clear-host
    cabecera
    Write-Host "-------------------------------------------------"
    Write-Host " ___________________________________________"
    Write-Host "|__menu_\___dms__\   frw  \__test_\__erro___\"
    Write-Host "|                                            |"
    Write-Host "| [1] - A�adir reglas estandar               |"
    Write-Host "| [2] - A�adir regla manual                  |"
    Write-Host "| [3] - A�ade reglas VPN                     |"
    Write-Host "| [q] - Salir                                |"
    Write-Host "|____________________________________________|"

    $hacer = Read-Host ">_ "

    switch($hacer){
        
        1{ menu_FirewallSub ; a�adelog -message "OPCION ELEGIDA 'Aplicar reglas standart' " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
        2{ add_regla        ; a�adelog -message "OPCION ELEGIDA 'Aplicar reglas manuales' " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
        3{ reglas_vpn       ; a�adelog -message "OPCION ELEGIDA 'Aplicar reglas VPN'      " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
        q{break}
    }
}
function menu_FirewallSub(){


    
    # Guardamos en $net_adapter los interfaces que cumplan con nuestros requisitos, que el tipo 'Address Family' no
    # sea de tipo IPv6, si que el interface index sea 1, 1 equivale al adaptador loopback o 127.0.0.1, de estos adaptadores, 
    # guardamos su nombre y la direccion ip para mostrarlas en un bucle
 
    $net_adapter = Get-NetIPAddress |  Where-Object {$_.AddressFamily -ne 'IPv6' -and $_.InterfaceIndex -ne 1}   | select IPAddress, InterfaceAlias

    

    Write-Host "      Firewall Manager "
    Write-Host "------------------------------------------------"
    Write-Host "SELECCIONE UN INTERFAZ/Todos PARA APLICAR REGLAS" -ForegroundColor Yellow
    Write-Host "-----------------------------------------------"
   
    # Desplegasmos todos los adaptadores en una lista junto con un numero para que el usuario
    # Seleccione en que adaptador aplicar las reglas o si aplicarlos en todos a la vez,
    # Esto ultimo se sabe si $fw_opcion es igual a $i o lo que es lo mismo $net_adapter + 1

 

    $i = 0
    foreach ($adaptador in $net_adapter) {
        
        Write-Host "OPCION /$i/" "[" $net_adapter[$i].IPAddress "|" $net_adapter[$i].InterfaceAlias  "]"
        $i++
    
    }
    $i++
    Write-Host "OPCION /$i/ TODAS"
    Write-Host "-------------------------------------------------"

    $fw_opcion = Read-Host ">_ "


    # Como se puede ver se despliega el menu con cada adaptador
    # y cuando sale del bucle a i se le suma 1 con lo que ya se puede manejar la opcion 
    # de aplicarlo en todos los interfaces


    if($fw_opcion -eq $i){
		a�adelog -message "A�ADIR REGLAS EN FIREWALL" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        
        for($i = 0 ; $i -le $net_adapter.Length ; $i++){
                     
             
             try{
			 
				a�adelog -message "SE VAN A A�ADIR REGLAS AL FIREWALL DE WINDOWS" -msgtype "OK   " -func_name $MyInvocation.MyCommand.Name
                New-NetFirewallRule -DisplayName "ALLOW QUITER TRAFFIC" -Action Allow  -Protocol TCP -InterfaceAlias $net_adapter[$i].InterfaceAlias  -LocalPort 31438, 6080, 80, 6443, 139, 445, 20, 21 -Direction inbound -RemoteAddress 0.0.0.0-255.255.255.254 -Verbose
                New-NetFirewallRule -DisplayName "ALLOW QUITER TRAFFIC" -Action Allow  -Protocol TCP -InterfaceAlias $net_adapter[$i].InterfaceAlias  -LocalPort 31438, 6080, 80, 6443, 139, 445, 20, 21 -Direction outbound -RemoteAddress 0.0.0.0-255.255.255.254 -Verbose
    
             }
			 
			 catch{
                
                a�adelog -message "ERROR AL A�ADIR REGLAS AL FIREWALL DE WINDOWS" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
				Write-Host "ERROR AL A�ADIR REGLAS AL FIREWALL DE WINDOWS" -ForegroundColor Red
				$FLAGS.errores.ReglasFirewall[0]++
            
			}
        }

    }
	
	a�adelog -message "FINALIZA A�ADIR REGLAS AL FIREWALL DE WINDOWS" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
    if($fw_opcion){
        
        a�ade_reglas_fw -num_interfaz $fw_opcion 

    }
    
}
function menu_Modif__Var_(){
    
    cabecera
    Write-Host "+-----M-E-N-U------P-A-R-A-M-E-T-R-O-S------+"
    testvar
    Write-Host " V [Cambiar Verbose -> $VerbosePreference]"
    Write-Host " q [Salir]"
    Write-Host "+-------------------------------------------+"
    
    $varnum = Read-Host ">>>> Introduce opci�n [1-12] "
    
    if($varnum -eq 'q' ){ break }

    $nuevoval = Read-Host ">>>> Introduce nuevo valor   "

    switch($varnum){
    
         1{$global:target = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'target' por: [$target]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         2{$global:username = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'username' por: [$username]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         3{$global:UnsecurePassword = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'password' por: [$password]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         4{$global:UvHome = $nuevoval; recarga; a�adelog -message "SE HA MODIFICADO LA VARIABLE 'Uv home' por: [$UvHome]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
		 5{$global:universe_ver = $nuevoval; recarga; a�adelog -message "SE HA MODIFICADO LA VARIABLE 'Ver UniVerse' por: [$universe_ver]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         6{$QuiterUnit = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'Quiterunit' por: [$QuiterUnit]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         7{$QuiterInst = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'Quiter inst' por: [$QuiterInst]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         8{$QuiterRepo = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'Quiter Repo' por: [$QuiterRepo]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
         9{$QuiterSetupDir = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'Quitersetup dir' por: [$QuiterSetupDir]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
        10{$QSetupDir = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'QsetUpdir' por: [$QSetupDir]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
        11{$global:cod_cliente = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'CodigoCliente' por: [$global:cod_cliente]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
        12{$global:codigo_pais = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'CodigoPais' por: [$global:codigo_pais]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
		13{$global:Diripv4 = $nuevoval; recarga;  a�adelog -message "SE HA MODIFICADO LA VARIABLE 'QDiripv4' por: [$global:Diripv4]" -msgtype "INFO "-func_name $MyInvocation.MyCommand.Name}
        v{if($VerbosePreference -eq 'continue'){ $VerbosePreference = 'SilentlyContinue'  }else{$VerbosePreference = 'continue'}}        
   }
}
function _instalacion_20_(){

        a�adelog -message "*** INSTALACION STANDARD" -msgtype "INFO " -func_name "begin"	
        Write-Host ""
        testvar
        Write-Host "Comienza la instalaci�n completa desatendida, recomendado llegar hasta el final (no abortar)"
        Write-Host ""
        $rand = Get-Random -Maximum 9999 -Minimum 999
        $respuesta = Read-Host ">>>> Introduce el codigo $rand para confirmar inicio "
        
        if($rand -eq $respuesta){
            Write-Host "Comenzando instalaci�n standard..."
            _Descargar_RepoWin_
			_Descargar_OpenVpn_
			_Crear_Directorios_ 
			if($FLAGS.utils.IsADEnable -eq $true){
                _Crear_Usuarios_AD_ # Fullok
            }
            else{
                _Crear_Usuarios_LS_ # Fullok    
            }
            _Instalar_OpenVpn__ 
            _Instalar_UniVerse_ 
            _Exe__QsisPermisos_ 
            _Exe__QuiterSetup__ 
            _Desplegar_WebPage_  
            _Instalar_QGateway_  
            _InstalConfig__IIS_  
            _Compartir_Dir_____  
            _Desplegar_Qibk____  
            _Desplegar_QDBLive_  
            _Desplegar_QawCli__
			_Configurar_Dir____
			_Configurar_FireW__
			_DesActivarNetBios_
			_Activar__RDesktop_
            _Limpieza_TmpFiles_ 
            #dar_parte
            Write-Host -ForegroundColor Yellow "Finalizada instalaci�n standard, consulte logs para informaci�n ampliada." 
            Write-Host -ForegroundColor Yellow "Recomendamos reiniciar el sistema."
			Write-Host -ForegroundColor Yellow "Recuerda cuando nuestras vpn est�n activas, ejecutar opci�n 21 del men� paso a paso."
        }
        
        a�adelog -message "*** INSTALACION STANDARD" -msgtype "INFO " -func_name "end  "	
}
function _instalacion_19_(){

        a�adelog -message "*** INSTALACION STANDARD" -msgtype "INFO " -func_name "begin"	
        Write-Host ""
        testvar
        Write-Host "Comienza la instalaci�n desatendida, recomendado llegar hasta el final (no abortar)"
        Write-Host ""
        $rand = Get-Random -Maximum 9999 -Minimum 999
        $respuesta = Read-Host ">>>> Introduce el codigo $rand para confirmar inicio "
        
        if($rand -eq $respuesta){
            Write-Host "Comenzando instalaci�n standard..."
			_Descargar_OpenVpn_
			_Crear_Directorios_ 
            if($FLAGS.utils.IsADEnable -eq $true){
                _Crear_Usuarios_AD_ # Fullok
            }
            else{
                _Crear_Usuarios_LS_ # Fullok    
            }
            _Instalar_OpenVpn__ 
            _Instalar_UniVerse_ 
            _Exe__QsisPermisos_ 
            _Exe__QuiterSetup__ 
            _Desplegar_WebPage_  
            _Instalar_QGateway_  
            _InstalConfig__IIS_  
            _Compartir_Dir_____  
            _Desplegar_Qibk____  
            _Desplegar_QDBLive_  
            _Desplegar_QawCli__
			_Configurar_Dir____
			_Configurar_FireW__
			_DesActivarNetBios_
			_Activar__RDesktop_
            _Limpieza_TmpFiles_ 
            #dar_parte
            Write-Host -ForegroundColor Yellow "Finalizada instalaci�n standard, consulte logs para informaci�n ampliada." 
            Write-Host -ForegroundColor Yellow "Recomendamos reiniciar el sistema."
			Write-Host -ForegroundColor Yellow "Recuerda cuando nuestras vpn est�n activas, ejecutar opci�n 21 del men� paso a paso."
        }
        
        a�adelog -message "*** INSTALACION STANDARD" -msgtype "INFO " -func_name "end  "	
}

#-- fin Funciones Menus

#-- Funciones Principales

function _Descargar_RepoWin_(){
    # 1 Descarga rclone y rclone.conf
	# 2 Descaga RepoWin desde GoogleDrive
	# 3 Check RepoWin
    
    a�adelog -message "1/20 DESCARGA REPOWIN" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [1/20] Descarga RepoWin"
    Write-Host ""
	Write-host -ForegroundColor Yellow ""
    Write-Host -ForegroundColor Yellow "/!\ Iniciada descarga del repositorio con los paquetes necesarios.    /!\"
    Write-Host -ForegroundColor Yellow "/!\  Dependiendo del ancho de banda, puede demorar alg�n tiempo.      /!\"
    Write-Host -ForegroundColor Yellow "/!\             Por favor, sea paciente gracias                       /!\"
    Write-host -ForegroundColor Yellow ""
	if (!(test-path -path $QuiterInst)) {new-item -path $QuiterInst -itemtype directory|Out-Null}
    if (!(test-path -path $QuiterRepo)) {new-item -path $QuiterRepo -itemtype directory|Out-Null}
	
    # 1 Descarga rclone y rclone.conf
	try{
		a�adelog -message "Descargando rclone.exe" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
		Set-Location $QuiterInst
	    Invoke-WebRequest -Uri "http://82.223.78.14/publico/ks/rclone.exe" -OutFile "rclone.exe"
		Invoke-WebRequest -Uri "http://82.223.78.14/publico/ks/rclone.conf" -OutFile "rclone.conf"
	}
	catch{ 
        a�adelog -message "No se pudo descargar rclone.exe" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name 
		Write-Host -ForegroundColor Red "No se pudo descargar rclone.exe" 
		$FLAGS.errores.DescargaRepositorio[0]++
	}
	finally{a�adelog -message "Finaliza la descarga de rclone.exe" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	
	# 2 Descaga RepoWin en GoogleDrive
    try {
		Set-Location $QuiterRepo
		a�adelog -message "Descargando RepoWin en GoogleDrive(Quiter-Sc)" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		#..\rclone.exe --config=..\rclone.conf lsl MyGoogleDrive:DirectDownload/RepoWin 
		#..\rclone.exe --config=..\rclone.conf tree MyGoogleDrive:DirectDownload/RepoWin
		#..\rclone.exe --config=..\rclone.conf copy --drive-acknowledge-abuse MyGoogleDrive:DirectDownload/RepoWin .
		#Failed to create file system for "MyRemoteConfig:DirectDownload/RepoWin": couldn't find root directory ID: googleapi: Error 403: Rate Limit Exceeded, rateLimitExceeded 
		#Ejecutando desde cmd funciona...
		cmd /c $("$QuiterInst\rclone.exe --config=$QuiterInst\rclone.conf lsl MyRemoteConfig:DirectDownload/RepoWin ")
		cmd /c $("$QuiterInst\rclone.exe --config=$QuiterInst\rclone.conf tree MyRemoteConfig:DirectDownload/RepoWin ")
		Write-Host "Contenido de RepoWin en GoogleDrive(Quiter-Sc)"
        Write-Host "La descarga continua..."
		cmd /c $("$QuiterInst\rclone.exe --config=$QuiterInst\rclone.conf copy --drive-acknowledge-abuse MyRemoteConfig:DirectDownload/RepoWin $QuiterRepo")   
		Write-Host "Descarga finalizada"
        dir $QuiterRepo    
	}
	catch{
       
		a�adelog -message "No se pudo descargar el Repositorio Win" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
		Write-Host "No se pudo descargar el Repositorio Win" -ForegroundColor Red
		$FLAGS.errores.DescargaRepositorio[0]++
	
	}
	finally{a�adelog -message "Finalizada descarga RepoWin" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
 
	# 3 Check RepoWin
	# Si no descarga RepoWin ok detenemos ejecuci�n
	#�{0:N2}� -f ((Get-ChildItem -path $QuiterRepo -recurse | Measure-Object -property length -sum ).sum /1GB)
	$RepoWinSize = �{0:N2}� -f ((Get-ChildItem -path $QuiterRepo -recurse | Measure-Object -property length -sum ).sum /1GB)
	Write-Host "Tama�o de $QuiterRepo = $RepoWinSize G"
	if ( $RepoWinSize -gt 1){
	        Write-Host "OK $QuiterRepo mayor de 1Giga."
			a�adelog -message "OK $RepoWin mayor de 1Giga" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name  				
	}
    else {
	        Write-Host -ForegroundColor Red "KO $QuiterRepo menor de 1Giga interrupimos proceso regresamos al men�."
			a�adelog -message "KO $RepoWin menor de 1Giga interrupimos proceso regresamos al men�." -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name  				
			Break
	}   
	
	a�adelog -message "1/20 DESCARGA REPOWIN" -msgtype "INFO " -func_name "end  "	

}
function _Descargar_OpenVpn_(){
    # 1 Descarga instalador OpenVpn
        
    a�adelog -message "2/20 DESCARGA INSTALADOR OPENVPN" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [2/20] Descarga Instalador OpenVpn"
    Write-Host ""
    if (!(test-path -path $QuiterInst)) {new-item -path $QuiterInst -itemtype directory|Out-Null}
	if (!(test-path -path $QuiterRepo)) {new-item -path $QuiterRepo -itemtype directory|Out-Null}
	
    # 1 Descarga instalador OpenVpn
    try {
        a�adelog -message "Descargando instalador OpenVpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
		Set-Location $QuiterRepo
        # switch ($WIN_VERSION) {
            # "2012" {
                    # Start-BitsTransfer -Source http://build.openvpn.net/downloads/releases/latest/openvpn-install-latest-stable-win7.exe;
				    # $global:VOpenVPN="openvpn-install-latest-stable-win7.exe"
                    # break;
            # }
            # "2016" {
                    # Start-BitsTransfer -Source http://build.openvpn.net/downloads/releases/latest/openvpn-install-latest-stable-win10.exe;  
				    # $global:VOpenVPN="openvpn-install-latest-stable-win10.exe"
                    # break;
            # }
            # "2019" {
                    # #Start-BitsTransfer -Source http://build.openvpn.net/downloads/releases/latest/openvpn-install-latest-stable-win10.exe;  
                    # Start-BitsTransfer -Source https://swupdate.openvpn.org/community/releases/OpenVPN-2.5.0-I601-amd64.msi;  
				    # $global:VOpenVPN="OpenVPN-2.5.0-I601-amd64.msi"
                    # break;
            # }
        #}
		#Start-BitsTransfer -Source https://swupdate.openvpn.org/community/releases/OpenVPN-2.5.0-I601-amd64.msi;
		# https://swupdate.openvpn.org/community/releases/OpenVPN-2.5.5-I602-amd64.msi
		Write-Host 'Descargando versi�n OpenVpn : ' $global:VOpenVPN
		Start-BitsTransfer -Source https://swupdate.openvpn.org/community/releases/$global:VOpenVPN;  
	}
	catch{
        a�adelog -message "No se pudo descargar instalador OpenVPN" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name 
		Write-Host -ForegroundColor Red "No se pudo descargar instalador OpenVPN" 
		$FLAGS.errores.DescargaRepositorio[0]++
    }
	finally{a�adelog -message "Finalizada descarga Instalador OpenVpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    
  a�adelog -message "2/20 DESCARGA INSTALADOR OPENVPN" -msgtype "INFO " -func_name "end  "	

}
function _Crear_Directorios_(){
    # 1 Crea Directorios
    
    a�adelog -message "3/20 CREA DIRECTORIOS" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [3/20] Crea Directorios"
    Write-Host ""
    	
    # 1 Crea Directorios	
    try {
		a�adelog -message "Creando directorios" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
		if (!(test-path -path $QuiterInst)) {new-item -path $QuiterInst -itemtype directory|Out-Null}
		if (!(test-path -path $QuiterRepo)) {new-item -path $QuiterRepo -itemtype directory|Out-Null}
        if (!(test-path -path $QuiterDir)) {new-item -path $QuiterDir -itemtype directory|Out-Null}
		if (!(test-path -path $QuiterUnit\InstalacionQuiterAutoWeb)) {new-item -path $QuiterUnit\InstalacionQuiterAutoWeb -itemtype directory|Out-Null}
		#Write-Host "Permisos en $QuiterDir"
		#Get-Acl $QuiterDir
	}
    catch{
		if (-not (Test-Path -LiteralPath $QuiterInst)) {a�adelog -message "El directorio $QuiterInst No se pudo crear" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name;Write-Host "El directorio $QuiterInst No se pudo crear"}
 		if (-not (Test-Path -LiteralPath $QuiterRepo)) {a�adelog -message "El directorio $QuiterRepo No se pudo crear" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name; Write-Host "El directorio $QuiterRepo No se pudo crear"}
		if (-not (Test-Path -LiteralPath $QuiterDir))  {a�adelog -message "El directorio $QuiterDir  No se pudo crear" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name; Write-Host "El directorio $QuiterDir No se pudo crear"}
		if (-not (Test-Path -LiteralPath $QuiterUnit\InstalacionQuiterAutoWeb)){a�adelog -message "El directorio $QuiterUnit\InstalacionQuiterAutoWeb No se pudo crear" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name; Write-Host "El directorio $QuiterUnit\InstalacionQuiterAutoWeb No se pudo crear"}
		$FLAGS.errores.CrearDirectorios[0]++
	}
    finally{a�adelog -message "Finalizada creaci�n de directorios" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    
	Set-Location $QuiterInst
    a�adelog -message "3/20 CREA DIRECTORIOS" -msgtype "INFO " -func_name "end  "	
}
function _Crear_Usuarios_LS_(){
    # 1 Alta grupo local GQUITER
    # 2 Alta usuarios/contrase�a partiendo del fichero usuarios.csv y generacion del ftp.cmd
    # 3 Agregar aquiter al grupo Administradores

    a�adelog -message "4/20 ALTA GRUPO GQUITER Y USUARIOS STANDARD" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [4/20] Alta grupo GQUITER y usuarios standard"
    Write-Host ""
    Write-Host "Users home dir..:" $QuiterDir\CONEXION
    Write-Host "Users group.....:" $global:UsrGroup
    Write-Host "Admin group.....:" $global:AdmGroup
    Write-Host "Print group.....:" $global:OpePrint
    
    # 1 Alta grupo local GQUITER
    try{
	    a�adelog -message "Alta grupo local GQUITER" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	
		net localgroup GQUITER /COMMENT:"Usuarios de la Aplicacion Quiter Auto" /ADD
        Write-Host "Creado grupo GQUITER"
        Add-LocalGroupMember -Group "$global:OpePrint" -Member GQUITER
        Write-Host "Agregado grupo GQuiter en grupo $global:OpePrint"
        Add-LocalGroupMember -Group "$global:UsrGroup" -Member GQUITER
        Write-Host "Agregado grupo GQuiter en grupo $global:UsrGroup"		
    }
	catch{
	    a�adelog -message "No se pudo crear el grupo GQUITER" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo crear el grupo GQUITER" 
		$FLAGS.errores.CreaUsuarios[0]++
    }
	finally{a�adelog -message "Finalizado alta del grupo local GQUITER" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
        
    # 2 Alta usuarios/contrase�a partiendo del fichero usuarios.csv
	try{
	    a�adelog -message "Alta usuarios/contrase�a partiendo del fichero usuarios.csv" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        a�adelog -message "Generaci�n de los comandos ftp para verificar login        " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        $global:FtpCmd = New-Item -Path ("$global:script_pos\logs\QsisFtpCmd_____{0:yyyyMMdd_HHmmss}.txt" -f (Get-Date)) -ItemType File
		$usuarios=Import-Csv -Path $global:QuiterInst\Qsis_Dms_Installer\resources\usuarios.csv
        foreach ($i in $usuarios){
            #Write-Host $i.nombre
            switch($i.nombre){
                "quiter" {
                        # agregamos c�digo de cliente a la contrase�a del fichero usuarios.csv
                        $password = $i.contra + $cod_cliente
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:quiterpass = $password
                        #Write-Host "usuario=quiter contase�a=$password"
                        #break
                    }
                "aquiter"{
                        # agregamos c�digo de cliente a la contrase�a del fichero usuarios.csv
                        $password = $i.contra + $cod_cliente
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:aquiterpass = $password
                        #Write-Host "usuario=gateway contase�a=$password"
                    }
                "gateway"{
                        # agregamos c�digo de cliente a la contrase�a del fichero usuarios.csv
                        $password = $i.contra + $cod_cliente
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:gatewaypass = $password
                        #Write-Host "usuario=gateway contase�a=$password"
                    }
				"ftpq"   {
						# no agregamos codigo de cliente porque la actualizaci�n no funcionar�a
                        $password = $i.contra
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:ftpqpass = $i.contra
                        #Write-Host "usuario=ftpq contase�a=$global:ftpqpass"
                    }
                default  {
                        # agregamos c�digo de cliente a la contrase�a 
                        $password = $i.contra + $cod_cliente
                        #Write-Host "usuario=$i.nombre contase�a=$password"
                    }
            }
            #net user $i.nombre $password /homedir:$QuiterDir\CONEXION /EXPIRES:never /COMMENT:"Usuario Maestro de Quiter Auto" /add    
            # esta instrucci�n pregunta S/N si la contrase�a es mayor de 14 caracteres cambiamos a New-LocalUser
            #Write-Host $password
            $SecurePassword = ConvertTo-SecureString $password -AsPlainText -Force
            New-LocalUser $i.nombre -AccountNeverExpires -PasswordNeverExpires -Password $SecurePassword -Description "Usuario Maestro de Quiter Auto"|Out-Null
            net user $i.nombre /homedir:$QuiterDir\CONEXION|Out-Null
            net localgroup GQUITER $i.nombre /ADD 
            #net localgroup $global:UsrGroup $i.nombre /ADD 
            #Write-Host "Creado usuario $i.nombre"
			#Ftp cmd
	        Add-Content $FtpCmd "open localhost"
			Add-Content $FtpCmd $i.nombre
			Add-Content $FtpCmd "$password"
			Add-Content $FtpCmd "cd /quiter"
			Add-Content $FtpCmd "ls"
			Add-Content $FtpCmd "close"
        }
		Add-Content $FtpCmd "quit"
        Write-Host "Usuarios standard agregados al grupo GQUITER"
        cmd /c $("net localgroup GQUITER")
    }               
	catch{
	    a�adelog -message "No se pudo dar de alta alguno de los usuarios standard" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo dar de alta alguno de los usuarios standard" 
		switch ($WIN_VERSION){
            "2012"{
				net user;				
				break;
            }
            {("2016" -or "2019")}{
				Get-LocalUser -Name "quiter","ftpq","gateway","conversion", "aquiter" | Select-Object Name;
                break;
            }
        }
		$FLAGS.errores.CreaUsuarios[0]++
    }
	finally{a�adelog -message "Finalizado alta usuarios/contrase�a partiendo del fichero usuarios.csv" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 3 Agregar aquiter en Administradores
	try{
	    a�adelog -message "Agregar aquiter en Administradores" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		Add-LocalGroupMember -Group $global:AdmGroup -Member "aquiter"
        Write-Host "Usuario aquiter agregado al grupo $global:AdmGroup"
        cmd /c $("net localgroup $global:AdmGroup")
    }
	catch{
	    a�adelog -message "El usuario aquiter no se pudo agregar al grupo $global:AdmGroup" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
		Write-Host -ForegroundColor Red "El usuario aquiter no se pudo agregar al grupo $global:AdmGroup" 
        $FLAGS.errores.CreaUsuarios[0]++
    }
	finally{a�adelog -message "Finalizado agregar aquiter al grupo $global:AdmGroup" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
  
	a�adelog -message "4/20 ALTA GRUPO GQUITER Y USUARIOS STANDARD" -msgtype "INFO " -func_name "end  "	
}
function _Crear_Usuarios_AD_(){
    # ACTIVE DIRECTORY
    # 1 Alta grupo GQUITER
    # 2 Alta usuarios/contrase�a partiendo del fichero usuarios.csv
    # 3 Agregar aquiter en Administradores

    a�adelog -message "4/20 ALTA GRUPO GQUITER Y USUARIOS STANDARD EN AD" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [4/20] Alta grupo GQUITER y usuarios standard en AD"
    Write-Host ""
    
    $domname_div = $env:USERDNSDOMAIN.Split('.')
    $pathad = "CN=Users, DC="
    $pathad += $domname_div[0]
    $pathad += ", DC= "
    $pathad += $domname_div[1]
    $homedir =  $QuiterDir + '\CONEXION'

    Write-Host "Dominio.........:" $domname_div
    Write-Host "CN,DC...........:" $pathad
    Write-Host "Users home dir..:" $homedir
    Write-Host "Users group.....:" $global:UsrGroup
    Write-Host "Admin group.....:" $global:AdmGroup
    Write-Host "Print group.....:" $global:OpePrint
    
    # 1 Alta grupo GQUITER
    try{
	    a�adelog -message "Alta grupo GQUITER" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	
		#New-ADGroup -Name "GQUITER" -SamAccountName GQUITER -GroupCategory Security -GroupScope DomainLocal -DisplayName "Grupo Local GQUITER" -Path $pathad -Description "GrupoLocal de usuarios para aplicaci�n Quiter"
		#Si damos de alta GQUITER como grupo local no podemos a�adirle en operadores de impresi�n.
		New-ADGroup -Name "GQUITER" -SamAccountName GQUITER -GroupCategory Security -GroupScope Global -DisplayName "Grupo Global GQUITER" -Path $pathad -Description "GrupoGlobal de usuarios para aplicaci�n Quiter"
	    Write-Host "Creado grupo GQUITER"
        Add-ADGroupMember "$global:OpePrint" -Members GQUITER
        Write-Host "Agregado grupo GQuiter en grupo $global:OpePrint"
    }
	catch{
	    a�adelog -message "No se pudo crear el grupo GQUITER" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo crear el grupo GQUITER" 
		$FLAGS.errores.CreaUsuarios[0]++
    }
	finally{a�adelog -message "Finalizado alta del grupo local GQUITER" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
        
    # 2 Alta usuarios/contrase�a partiendo del fichero usuarios.csv
	try{
	    a�adelog -message "Alta usuarios/contrase�a partiendo del fichero usuarios.csv" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        a�adelog -message "Generaci�n de los comandos ftp para verificar login        " -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        $global:FtpCmd = New-Item -Path ("$global:script_pos\logs\QsisFtpCmd_____{0:yyyyMMdd_HHmmss}.txt" -f (Get-Date)) -ItemType File
        $usuarios=Import-Csv -Path $global:QuiterInst\Qsis_Dms_Installer\resources\usuarios.csv
        foreach ($i in $usuarios) {
            #Write-Host $i.nombre
            switch($i.nombre){
                "quiter" {
                        # agregamos c�digo de cliente a la contrase�a del fichero usuarios.csv
                        $password = $i.contra + $cod_cliente
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:quiterpass = $password
                        #Write-Host "usuario=quiter contase�a=$password"
                        #break
                    }
                "aquiter"{
                        # agregamos c�digo de cliente a la contrase�a del fichero usuarios.csv
                        $password = $i.contra + $cod_cliente
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:aquiterpass = $password
                        #Write-Host "usuario=gateway contase�a=$password"
                    }
                "gateway"{
                        # agregamos c�digo de cliente a la contrase�a del fichero usuarios.csv
                        $password = $i.contra + $cod_cliente
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:gatewaypass = $password
                        #Write-Host "usuario=gateway contase�a=$password"
                    }
				"ftpq"   {
						# no agregamos codigo de cliente porque la actualizaci�n no funcionar�a
                        $password = $i.contra
                        # exportamos la contrase�a para utilizarla en otras funciones
                        $global:ftpqpass = $i.contra
                        #Write-Host "usuario=ftpq contase�a=$global:ftpqpass"
                    }
                default  {
                        # agregamos c�digo de cliente a la contrase�a 
                        $password = $i.contra + $cod_cliente
                        #Write-Host "usuario=$i.nombre contase�a=$password"
                    }
            }
            #Write-Host $password
            $SecurePassword = ConvertTo-SecureString $password -AsPlainText -Force
            New-ADUser -SamAccountName $i.nombre -Name $i.nombre -UserPrincipalName $i.nombre -AccountPassword $SecurePassword -Enabled $true `
            -PasswordNeverExpires $true -Path $pathad -homedirectory $homedir
            Add-ADGroupMember "GQUITER" -Members $i.nombre
            Add-ADGroupMember $global:UsrGroup -Members $i.nombre
            #Write-Host "Creado usuario $i.nombre"
   			#Ftp cmd
	        Add-Content $FtpCmd "open localhost"
			Add-Content $FtpCmd $i.nombre
			Add-Content $FtpCmd "$password"
			Add-Content $FtpCmd "cd /quiter"
			Add-Content $FtpCmd "ls"
			Add-Content $FtpCmd "close"       
        }
    }               
	catch{
	    a�adelog -message "No se pudo dar de alta alugno de los usuarios standard" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo dar de alta alugno de los usuarios standard" 
		$FLAGS.errores.CreaUsuarios[0]++
    }
	finally{a�adelog -message "Finalizado alta usuarios/contrase�a partiendo del fichero usuarios.csv" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 3 Agregar aquiter en Administradores
	try{
	    a�adelog -message "Agregar usuario aquiter al grupo Administradores" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Add-ADGroupMember $global:AdmGroup -Members "aquiter"
        Write-Host "Usuario aquiter agregado al grupo Administradores"
    }
	catch{
	    a�adelog -message "Usuario aquiter no pudo ser agregado al grupo Administradores" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "Usuario aquiter no pudo ser agregado al grupo Administradores" 
        $FLAGS.errores.CreaUsuarios[0]++
    }
	finally{a�adelog -message "Finalizado agregar usuario aquiter al grupo Administradores" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    
	a�adelog -message "4/20 ALTA GRUPO GQUITER Y USUARIOS STANDARD EN AD" -msgtype "INFO " -func_name "end  "	
}      
function _Instalar_OpenVpn__(){
    # 1 Lanzar instalaci�n de OpenVpn
    # 2 Configurar servicio OpenVpn como de inicio autom�tico, en version 2.5 ya no es necesario
    # 3 Copia de los archivos .ovpn
    # 4 A�adir interfaces
    # 5 Renombrar interfaces y deshabilitar firewall en las interfaces vpn
    # 6 Modificar claves del registro tcp

    a�adelog -message "5/20 INSTALA Y CONFIGURA OPENVPN" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [5/20] Instala y configura OpenVpn"
    Write-Host ""

    # 1 Lanzar instalaci�n OpenVpn
	try {
        Set-Location $QuiterInst
        a�adelog -message "Lanzando instalador OpenVpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Write-Host "Instalando $global:VOpenVPN"
        # switch ($WIN_VERSION) {
            # "2012" {
                    # #Version 2.4 instalador .exe
                    # $global:VOpenVPN="openvpn-install-latest-stable-win7.exe"
                    # Start-Process -Wait "$QuiterRepo\$global:VOpenVPN" /S -Verbose
                    # break;
            # }
            # "2016" {
                    # #Version 2.4 instalador .exe
                    # $global:VOpenVPN="openvpn-install-latest-stable-win10.exe"
                    # Start-Process -Wait "$QuiterRepo\$global:VOpenVPN" /S -Verbose
                    # break;
            # }
            # "2019" {
                    # #Version 2.5 instalador .msi
                    # $global:VOpenVPN="OpenVPN-2.5.0-I601-amd64.msi"
                    # #MsiExec /i $QuiterRepo\$global:VOpenVPN ADDLOCAL=OpenVPN.GUI,OpenVPN.Service,OpenVPN,Drivers,Drivers.Wintun,Drivers.TAPWindows6 /passive
                    # Start-Process -Wait "MsiExec.exe" -ArgumentList "/i $QuiterRepo\$global:VOpenVPN ADDLOCAL=OpenVPN.GUI,OpenVPN.Service,OpenVPN,Drivers,Drivers.Wintun,Drivers.TAPWindows6 /qn /norestart"
                    # break;
            # }
        # }
		Start-Process -Wait "MsiExec.exe" -ArgumentList "/i $QuiterRepo\$global:VOpenVPN ADDLOCAL=OpenVPN.GUI,OpenVPN.Service,OpenVPN,Drivers,Drivers.Wintun,Drivers.TAPWindows6 /qn /norestart"
        $openVpn_path = $env:ProgramFiles
        $openVpn_path += "\OpenVPN"
        if((Test-Path -Path $openVpn_path -Verbose) -eq $true){Write-Host "OpenVPN instalado"} 
	}
	catch{
		a�adelog -message "OpenVpn No se pudo instalar" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name 
		Write-Host -ForegroundColor Red "OpenVpn No se pudo instalar" 
		$FLAGS.errores.OpenVpn[0]++
	}
	finally{a�adelog -message "Finalizada instalaci�n OpenVpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # # 2 Configurar servicio OpenVpn como de inicio autom�tico
    # try{
        # switch ($WIN_VERSION) {
            # {$_ -in "2012","2016"}{
                    # #Version 2.4 instalador .exe
		            # a�adelog -message "Establecer servicio OpenVpn de arranque autom�tico" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name   
                    # Set-Service OpenVPNService -startuptype "Automatic"
		            # if((Get-Service -Name OpenVPNService) -eq $true){Write-Host "OpenVPN a�adido como servicio"}
                    # Write-Host "NO-2019"
                    # break;
            # }
            # "2019"{
                    # #Version 2.5 instalador .msi
                    # break;
            # }
        # }
	# }
	# catch{
        # a�adelog -message "El servicio OpenVpn no se estableci� de arranque autom�tico" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name 
		# Write-Host -ForegroundColor Red "El servicio OpenVpn no se estableci� de arranque autom�tico" 
		# $FLAGS.errores.OpenVpn[0]++
     # }
	# finally{a�adelog -message "Finaliza la configuraci�n del servicio OpenVpn como de inicio autom�tico" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
   
    # 3 Copia de los archivos .ovpn
    try{
        a�adelog -message "Copiando archivos de configuraci�n .ovpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name   
        # switch ($WIN_VERSION) {
            # {$_ -in "2012","2016"} {
                    # #Version 2.4 instalador .exe
		            # Copy-Item -Path $QuiterRepo\*.ovpn -Destination "c:\Program Files\OpenVPN\config"
                    # break;
            # }
            # "2019" {
                    # #Version 2.5 instalador .msi
                    # Copy-Item -Path $QuiterRepo\*.ovpn -Destination "c:\Program Files\OpenVPN\config-auto"
					# Add-Content "c:\Program Files\OpenVPN\config-auto\openvpn15.ovpn" "cipher BF-CBC"
                    # break;
            # }
        # }
		Copy-Item -Path $QuiterRepo\*.ovpn -Destination "$openVpn_path\config-auto"
		#Add-Content "$openVpn_path\config-auto\openvpn15.ovpn" "cipher BF-CBC"
    }
	catch{
        a�adelog -message "No se pudieron copiar los archivos de configuraci�n .ovpn" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudieron copiar los archivos de configuraci�n .ovpn" 
		$FLAGS.errores.OpenVpn[0]++
    }
	finally{a�adelog -message "Finalizada copia de archivos de configuraci�n .ovpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 4 A�adir interfaces
	try{
        a�adelog -message "A�adiendo interfaces para OpenVpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
        # switch ($WIN_VERSION) {
            # {$_ -in "2012","2016"} {
                    # #Version 2.4 instalador .exe
                    # Get-Content "C:\Program Files\TAP-Windows\bin\addtap.bat" -raw | % {$_ -replace "pause", ""} | Set-Content "C:\Program Files\TAP-Windows\bin\addtap_sinpause.bat"
                    # Start-Process -Wait "C:\Program Files\TAP-Windows\bin\addtap_sinpause.bat" -Verbose
		            # Start-Process -Wait "C:\Program Files\TAP-Windows\bin\addtap_sinpause.bat" -Verbose
                    # break;
            # }
            # "2019" {
                    # #Version 2.5 instalador .msi
                    # Start-Process -Wait "C:\Program Files\OpenVpn\bin\tapctl.exe" -ArgumentList "create --name Tun1000" -Verbose
                    # Start-Process -Wait "C:\Program Files\OpenVpn\bin\tapctl.exe" -ArgumentList "create --name TunQis" -Verbose
                    # break;
            # }
        # }
		Start-Process -Wait "$openVpn_path\bin\tapctl.exe" -ArgumentList "create --name Tun1000" -Verbose
        Start-Process -Wait "$openVpn_path\bin\tapctl.exe" -ArgumentList "create --name TunQis" -Verbose
		$pais = $PAISES[$global:codigo_pais].CodigoPais
		switch($pais){
                "MX"{
						Write-Host "Dms Mexicano alta interface openvpn para QuiterMx y Qis"
						Start-Process -Wait "$openVpn_path\bin\tapctl.exe" -ArgumentList "create --name QuiterVpnMx" -Verbose
						Start-Process -Wait "$openVpn_path\bin\tapctl.exe" -ArgumentList "create --name TunQisNa" -Verbose
                    }
                "CO"{
						Write-Host "Dms Colombiano alta interface openvpn para Qis"
						Start-Process -Wait "$openVpn_path\bin\tapctl.exe" -ArgumentList "create --name TunQisLatam" -Verbose
                    }
                "CL"{
						Write-Host "Dms Chileno alta interface openvpn para Qis"
						Start-Process -Wait "$openVpn_path\bin\tapctl.exe" -ArgumentList "create --name TunQisLatam" -Verbose
                    }					
                default{
						Write-Host ""
                    }
        }
	}
	catch{
		a�adelog -message "No se han podido a�adir las nuevas interfaces OpenVPN" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
		Write-Host -ForegroundColor Red "No se han podido a�adir las nuevas interfaces OpenVPN" 
		$FLAGS.errores.OpenVpn[0]++
	}
	finally{a�adelog -message "Finaliza la instalaci�n de nuevas interfaces para OpenVpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	    
    # 5 Renombrar interfaces y deshabilitar firewall	
    try{
	    a�adelog -message "Renombrar interfaces" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        # switch ($WIN_VERSION) {
            # {$_ -in "2012","2016"} {
                    # #Version 2.4 instalador .exe
            		# Rename-NetAdapter -InterfaceDescription 'TAP-Windows Adapter V9' -NewName 'QuiterVpn'
                    # Rename-NetAdapter -InterfaceDescription 'TAP-Windows Adapter V9 #2' -NewName 'Tun1000'
                    # Rename-NetAdapter -InterfaceDescription 'TAP-Windows Adapter V9 #3' -NewName 'TunQis'
                    # break;
            # }
            # "2019" {
                    # #Version 2.5 instalador .msi
		            # Rename-NetAdapter -InterfaceDescription 'TAP-Windows Adapter V9' -NewName 'QuiterVpn'                    
                    # break;
            # }
        # }
		Rename-NetAdapter -InterfaceDescription 'TAP-Windows Adapter V9' -NewName 'QuiterVpn'                    
        Disable-NetAdapterBinding -Name "QuiterVpn" -ComponentID ms_tcpip6 
        Disable-NetAdapterBinding -Name "QuiterVpn" -ComponentID ms_server 
        Disable-NetAdapterBinding -Name "Tun1000" -ComponentID ms_tcpip6 
        Disable-NetAdapterBinding -Name "Tun1000" -ComponentID ms_server 
        Disable-NetAdapterBinding -Name "TunQis" -ComponentID ms_tcpip6 
        Disable-NetAdapterBinding -Name "TunQis" -ComponentID ms_server 
        Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "QuiterVpn", "Tun1000", "TunQis"
        Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "QuiterVpn", "Tun1000", "TunQis"
		Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "QuiterVpn", "Tun1000", "TunQis"  
		$pais = $PAISES[$global:codigo_pais].CodigoPais
		switch($pais){
                "MX"{
						Write-Host "Dms Mexicano config QuiterVpnMx y TunQisLatam"
						Disable-NetAdapterBinding -Name "QuiterVpnMx" -ComponentID ms_tcpip6 
						Disable-NetAdapterBinding -Name "QuiterVpnMx" -ComponentID ms_server
						Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "QuiterVpnMx"
						Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "QuiterVpnMx"
						Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "QuiterVpnMx"
						Disable-NetAdapterBinding -Name "TunQisNa" -ComponentID ms_tcpip6 
						Disable-NetAdapterBinding -Name "TunQisNa" -ComponentID ms_server
						Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "TunQisNa"
						Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "TunQisNa"
						Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "TunQisNa"
                    }
                "CO"{
						Write-Host "Dms Colombiano config TunQisLatam"
						Disable-NetAdapterBinding -Name "TunQisLatam" -ComponentID ms_tcpip6 
						Disable-NetAdapterBinding -Name "TunQisLatam" -ComponentID ms_server
						Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "TunQisLatam"
						Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "TunQisLatam"
						Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "TunQisLatam"
                    }
                default{
						Write-Host ""
                    }
        }
    }
	catch{
		a�adelog -message "No se pudo renombrar interfaces" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo renombrar interfaces" 
		$FLAGS.errores.OpenVpn[0]++
    }
	finally{a�adelog -message "Finalizado renombrado de interfaces" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 6 Modificar claves del registro tcp
	if ((Test-Path -LiteralPath "$QuiterRepo\Tcp_ip_parameters.reg") -eq $true){
	        a�adelog -message "Encontrado fichero .reg con par�metros tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name  				
	}
    else {
		a�adelog -message "No se pudo encontrar .reg con par�metros tcp/ip" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name  
		Write-Host -ForegroundColor Red "No se pudo encontrar .reg con par�metros tcp/ip" 
		$FLAGS.errores.OpenVpn[0]++
	}   
	try {
		a�adelog -message "A�adir .reg con par�metros tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name  
		#Start-Process -Wait $QuiterRepo\Tcp_ip_parameters.reg -Verbose
        Invoke-Command {reg import $QuiterRepo\Tcp_ip_parameters.reg *>&1 | Out-Null}
	}
	catch{
		a�adelog -message "No se pudo a�adir al registro .reg con par�metros tcp/ip" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name  
		Write-Host -ForegroundColor Red "No se pudo a�adir al registro .reg con par�metros tcp/ip" 
		$FLAGS.errores.OpenVpn[0]++
	}
	finally{a�adelog -message "Finaliza a�adir .reg con par�metros tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "5/20 INSTALA Y CONFIGURA OPENVPN" -msgtype "INFO " -func_name "end  "	
} 
function _Instalar_UniVerse_(){
    # 1 Descomprimir instalador de UniVerse
    # 2 Lanzar instalador de UniVerse y modificar uvconfig 
    
    a�adelog -message "6/20 INSTALA UNIVERSE" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [6/20] Instala UniVerse"
    Write-Host ""
    #Write-Host -ForegroundColor Yellow "/!\  Lanzamos el instalador desatendido de UniVerse.  /!\" 
    #Write-Host -ForegroundColor Yellow "/!\  Por favor, mantenga foco en la ventana actual.   /!\"
    #Write-Host -ForegroundColor Yellow "/!\  Evite contacto con teclado/rat�n mientras avanza /!\"
    #Write-Host -ForegroundColor Yellow "/!\  el instalador. Cuando finalice puede cambiar el  /!\"
    #Write-Host -ForegroundColor Yellow "/!\  foco e interacturar con teclado/rat�n, gracias.  /!\"
    Write-Host ""
    sleep 5
	
    # 1 Descomprimir instalador UniVerse
    Set-Location $QuiterInst
    switch($global:universe_ver){
            11.2.5{
				descomprime -origen $QuiterRepo\uv_windows_11.2.5.4819_64bit.zip -destino $QuiterInst -funcion $MyInvocation.MyCommand.Name
			}
            11.3.1{
				descomprime -origen $QuiterRepo\uv_windows_11.3.1.6025_64bit.zip -destino $QuiterInst -funcion $MyInvocation.MyCommand.Name
			}
            11.3.2{
				descomprime -origen $QuiterRepo\uv_windows_11.3.2.7001_64bit.zip -destino $QuiterInst -funcion $MyInvocation.MyCommand.Name
			}
            11.3.4{
				descomprime -origen $QuiterRepo\uv_windows_11.3.4_64bit.zip -destino $QuiterInst -funcion $MyInvocation.MyCommand.Name
			}
            default{
				Write-Host "Versi�n UniVerse $global:universe_ver no contemplada, intentamos con 11.3.4"
				descomprime -origen $QuiterRepo\uv_windows_11.3.4_64bit.zip -destino $QuiterInst -funcion $MyInvocation.MyCommand.Name
				BREAK
			}
    }
    
	# 2 Lanzar instalador de UniVerse y modificar uvconfig  
    try {
		a�adelog -message "Lanzamos instalador desatendido de UniVerse" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		Set-Location $QuiterInst\universe_$global:universe_ver\UNIVERSE\I386
		#Start-Process -Wait .\UniVerseAutoItScript.exe -Verbose
		Write-Host -ForegroundColor Yellow "/!\  Lanzamos instalaci�n desatendida de UniVerse  /!\" 
		cmd /c setup.exe /s /f1"$QuiterInst\universe_$global:universe_ver\UNIVERSE\I386\setup.iss"
        sleep 5
		Write-Host -ForegroundColor Yellow "/!\  UniVerse instalado /!\" 
		Set-Location $global:UvHome
		#Write-Host "Permisos en $global:UvHome"
		#Get-Acl $global:UvHome
		Copy-Item -LiteralPath c:\uv\uv\uvconfig -Destination c:\uv\uv\uvconfig.bak
		Get-Content c:\uv\uv\uvconfig -raw | % {$_ -replace "NUSERS   256", "NUSERS   900"} | Set-Content c:\uv\uv\uvconfig.1
		Get-Content c:\uv\uv\uvconfig.1 -raw | % {$_ -replace "BLKMAX 8192", "BLKMAX 65536"} | Set-Content c:\uv\uv\uvconfig
        $UvUsersLog = New-Item -Path ("$global:script_pos\logs\QsisUvUsersAdd_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
        cmd /c $UvHome\bin\uv "LIST UV_USERS NOPAGE" 1>$UvUsersLog 
        cmd /c $UvHome\bin\uv "GRANT CONNECT TO aquiter,quiter,gateway;" 1>>$UvUsersLog
        cmd /c $UvHome\bin\uv "GRANT DBA TO aquiter,quiter,gateway;" 1>>$UvUsersLog 
        cmd /c $UvHome\bin\uv "LIST UV_USERS NOPAGE" 1>>$UvUsersLog 
		Write-Host "Deteniendo UniVerse"
        Stop-Service unirpc 
		Stop-Service universe -Force
		.\bin\uvregen
		Write-Host "Iniciando UniVerse"
        Start-Service unirpc 
		Start-Service universe 
		Start-Service uvtelnet 
		sleep 3
        # mostrar proceso uv arrancados
		$proc_uv = ps | findstr uv 
		if($proc_uv){Write-Host $proc_uv}
	}
	catch{
	    a�adelog -message "No se puediron encontrar procesos UniVerse" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se puediron encontrar procesos UniVerse" 
    	$FLAGS.errores.Universe[0]++
	}
    finally{a�adelog -message "Finaliza instalaci�n desatendida de UniVerse" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "6/20 INSTALA UNIVERSE" -msgtype "INFO " -func_name "end  "
} 
function _Exe__QsisPermisos_(){
    # Ejecutamos permisos antes de plataformar para que java no cree la carpeta y le ponga permisos
    # de este forma evitamos problemas al plataformar con usuario aquiter aunque sea administrador.
    # 1 Lanzar ejecuci�n de QsisPermisos.bat   
    
    a�adelog -message "7/20 ASIGNANDO PERMISOS" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [7/20] Asigna permisos"
    Write-Host ""

    # 1 Lanzar ejecuci�n de QsisPermisos.bat
    try{
        a�adelog -message "Lanzar ejecuci�n de QsisPermisos.bat $global:target" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Set-Location $global:script_pos\logs
		Write-Host -ForegroundColor Yellow "Permisos en $QuiterDir antes de QsisPermisos."
		Get-Acl $QuiterDir
		Write-Host -ForegroundColor Yellow "Permisos en $global:UvHome antes de QsisPermisos."
		Get-Acl $global:UvHome
		# cuando se ejecuta por primera vez UniVerse no esta configurado y necesitamos pasar el parametro donde esta quiter
        Write-Host -ForegroundColor Yellow "Ejecutamos $QuiterInst\RepoWin\QSISpermisos.bat"
		cmd /c $QuiterInst\RepoWin\QSISpermisos.bat $global:target
		Write-Host ""
		Write-Host -ForegroundColor Yellow "Permisos en $QuiterDir despu�s de QsisPermisos."
		Get-Acl $QuiterDir
		Write-Host -ForegroundColor Yellow "Permisos en $global:UvHome despu�s de QsisPermisos."
		Get-Acl $global:UvHome
    }
	catch{
        a�adelog -message "No se pudo ejecutar QsisPermisos.bat" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo ejecutar QsisPermisos.bat" 
	}
    finally{a�adelog -message "Finalizada ejecuci�n de QsisPermisos.bat" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
  
	a�adelog -message "7/20 ASIGNANDO PERMISOS" -msgtype "INFO " -func_name "end  "
}
function _Exe__QuiterSetup__(){
    # 1 Descomprimir QuiterSetup
    # 2 Configurar SetupPlataforma.properties, generar QsisGen4glCmd.txt y QsisPlataformar.bat
    # 3 Lanzar ejecuci�n QsisPlataformar.bat
    
    a�adelog -message "8/20 DESPLEGANDO QUITERSETUP" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [8/20] Despliega QuiterSetup"
    Write-Host ""
	# Cuando lanzamos ejecucion manual no tenemos carpeta quiter ni permisos pasados entonces no plataforma
	$global:aquiterpass = if (!$global:aquiterpass) {"HecnlsndS.$global:cod_cliente"} else {$global:aquiterpass}
	if (!(test-path -path $QuiterDir)) {
		new-item -path $QuiterDir -itemtype directory|Out-Null
		Set-Location $global:script_pos\logs
        cmd /c $QuiterInst\RepoWin\QSISpermisos.bat $global:target
	}
   
    # 1 Descomprimir QuiterSetup
    Set-Location $QuiterInst
    $QuiterSetupFile = Get-ChildItem .\RepoWin\QuiterSetup*.zip -name
    descomprime -origen $QuiterRepo\$QuiterSetupFile -destino $QuiterInst -funcion $MyInvocation.MyCommand.Name
    
    # 2 Configurar SetupPlataforma.properties, generar QsisGen4glCmd.txt, generar QsisResizeCmd.txt y QsisPlataformar.bat
    # Remplazamos valores del archivo setup_plataforma y creamos un archivo para nuestras necesidades
    # Encadenamos despu�s de la ejecuci�n de QuiterSetup las llamadas a UniVerse dentro de QsisPlataformar.bat
    try{
		Write-Host 'QuiterSetup config'
        # Setup_Plataforma.properties
        a�adelog -message "Configurando setup_plataforma.properties" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		Get-Content $QuiterRepo\setup_plataforma.properties -raw | % {$_ -replace "/usr/uv", "c\:\\uv\\uv"} | Set-Content setup_plataforma.properties.1
        # Plataformamos con usuario aquiter
		#Get-Content setup_plataforma.properties.1 -raw | % {$_ -replace "rootpass", $global:UnsecurePassword} | Set-Content setup_plataforma.properties.2
        #Get-Content setup_plataforma.properties.2 -raw | % {$_ -replace "root", $username} | Set-Content setup_plataforma.properties.1
		Get-Content setup_plataforma.properties.1 -raw | % {$_ -replace "rootpass", $global:aquiterpass } | Set-Content setup_plataforma.properties.2
        Get-Content setup_plataforma.properties.2 -raw | % {$_ -replace "root", "aquiter" } | Set-Content setup_plataforma.properties.1    
        Get-Content setup_plataforma.properties.1 -raw | % {$_ -replace "/u2/instalaciones/DMS/quitersetup", $QSetupDir} | Set-Content setup_plataforma.properties.2
        Get-Content setup_plataforma.properties.2 -raw | % {$_ -replace "/u2/quiter", $QSetupQDir} | Set-Content setup_plataforma.properties
	    Remove-Item setup_plataforma.properties.2
        Remove-Item setup_plataforma.properties.1   
		Copy-Item -Path setup_plataforma.properties -Destination quitersetup\conf\setup_plataforma.properties

        # QsisGen4glCmd.txt
        a�adelog -message "Configurando QsisGen4glCmd.txt" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        #$GenCmd = $QuiterSetupDir+"\bin\QsisGen4glCmd.txt"
		$GenCmd = New-Item -Path ("$global:script_pos\logs\QsisGen4glCmd__{0:yyyyMMdd_HHmmss}.txt" -f (Get-Date)) -ItemType File
        $GenLog = New-Item -Path ("$global:script_pos\logs\QsisGen4glCmd__{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
        Set-Content $GenCmd "DATE"
		Add-Content $GenCmd "QSIS.PREPBATCH"
		Add-Content $GenCmd "QSIS.RUN DATE"
		Add-Content $GenCmd "QSIS.RUN DOS /C `"echo %cd%`""
		Add-Content $GenCmd "WHO"
		Add-Content $GenCmd "DROP TRIGGER GNFILE ALL;"
		Add-Content $GenCmd "QSIS.RUN ICATALOG BP CENTRAL.TRIGGER"
		# Recorrer cuentas instalando triggers
        # CONEXION no est� preparado para triggers como QSIS.RUN pasa por CONEXION se rompe el proceso
        $cuentas = @('COMERCIAL', 'CONTA5', 'POSVENTA5', 'GEN4GL')
		foreach ($i in $cuentas){
			Add-Content $GenCmd "LOGTO $i"
			Add-Content $GenCmd "WHO"
			Add-Content $GenCmd "RUN BP INSTALL.TRIGGERS"
		}
		Add-Content $GenCmd "LOGTO GEN4GL"
		Add-Content $GenCmd "WHO"
		Add-Content $GenCmd "DATE"
		Add-Content $GenCmd "CT PAR_GEN GEN -NO.PAGE"
		Add-Content $GenCmd "DATE"
		Add-Content $GenCmd "ED PAR_GEN GEN"
        Add-Content $GenCmd "44"
        Add-Content $GenCmd "DE"
        Add-Content $GenCmd "I"
        Add-Content $GenCmd "$QuiterDir\qjava"
        Add-Content $GenCmd ""
        Add-Content $GenCmd "53"
        Add-Content $GenCmd "DE"
        Add-Content $GenCmd "I"
        Add-Content $GenCmd "GQUITER"
        Add-Content $GenCmd ""
        Add-Content $GenCmd "54"
        Add-Content $GenCmd "DE"
        Add-Content $GenCmd "I"
        Add-Content $GenCmd "1"
        Add-Content $GenCmd ""
        Add-Content $GenCmd "42"
        Add-Content $GenCmd "DE"
        Add-Content $GenCmd "I"
        Add-Content $GenCmd "http://$global:Diripv4`:6080/"
        Add-Content $GenCmd ""
        Add-Content $GenCmd "57"
        Add-Content $GenCmd "DE"
        Add-Content $GenCmd "I"
        Add-Content $GenCmd " "
        Add-Content $GenCmd ""
        Add-Content $GenCmd "59"
        Add-Content $GenCmd "DE"
        Add-Content $GenCmd "I"
        Add-Content $GenCmd "c:\uv\uv"
        Add-Content $GenCmd ""
        Add-Content $GenCmd "FI"
        Add-Content $GenCmd ""
        Add-Content $GenCmd "RUN BP PUTUSRTRANS"
        Add-Content $GenCmd "ftpq"
        Add-Content $GenCmd "$global:ftpqpass"
        Add-Content $GenCmd "QUITER"
        Add-Content $GenCmd ""
		Add-Content $GenCmd "DATE"
		Add-Content $GenCmd "CT PAR_GEN GEN -NO.PAGE"
		Add-Content $GenCmd "DATE"
		
		# QsisResizeCmd.txt
        a�adelog -message "Configurando QsisResizeCmd.txt" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        $ResCmd = New-Item -Path ("$global:script_pos\logs\QsisResizeCmd__{0:yyyyMMdd_HHmmss}.txt" -f (Get-Date)) -ItemType File
        $ResLog = New-Item -Path ("$global:script_pos\logs\QsisResizeCmd__{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
        Set-Content $ResCmd "DATE"
		Add-Content $ResCmd "LOGTO UV"
		Add-Content $ResCmd "LISTU"
		Add-Content $ResCmd "LIST.READU EVERY FILEMAP"
		Add-Content $ResCmd "PORT.STATUS"
		Add-Content $ResCmd "UNLOCK ALL"
		Add-Content $ResCmd "DATE"
		Add-Content $ResCmd "LOGTO COMERCIAL"
		Add-Content $ResCmd "DIMENSION FMCONCPT"
		Add-Content $ResCmd "RESIZE FMCONCPT 18 1201 4"
		Add-Content $ResCmd "DIMENSION FMCONCPT"
		Add-Content $ResCmd "DATE"
		Add-Content $ResCmd "LOGTO GEN4GL"
		Add-Content $ResCmd "DIMENSION GNFILE"
		Add-Content $ResCmd "RESIZE GNFILE 18 1201 4"
		Add-Content $ResCmd "DIMENSION GNFILE"
		Add-Content $ResCmd "DATE"
		Add-Content $ResCmd "DIMENSION ATRIBUTOS"
		Add-Content $ResCmd "RESIZE ATRIBUTOS 18 1201 4"
		Add-Content $ResCmd "DIMENSION ATRIBUTOS"
		Add-Content $ResCmd "DATE"
		
        # QsisPlataformar.bat
        a�adelog -message "Configurando QsisPlataformar.bat" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		Set-Location $QuiterSetupDir\bin
		Copy-Item -Path plataformar.bat -Destination QsisPlataformar.bat
        $QsisIniUvLog = New-Item -Path ("$global:script_pos\logs\QsisIniUv______{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
        $QsisTrigeLog = New-Item -Path ("$global:script_pos\logs\QsisTriggers___{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
		Add-Content QsisPlataformar.bat "`r`ncd $QuiterDir\GEN4GL`r`n$UvHome\bin\uv QSIS.INI.UV 1>$QsisIniUvLog"
		Add-Content QsisPlataformar.bat "`r`ncd $QuiterDir\GEN4GL`r`n$UvHome\bin\uv <$GenCmd 1>$GenLog"
        Add-Content QsisPlataformar.bat "`r`ncd $QuiterDir\GEN4GL`r`n$UvHome\bin\uv <$ResCmd 1>$ResLog"
		Add-Content QsisPlataformar.bat "`r`nxcopy /Y $QuiterSetupDir\logs\*.* $global:script_pos\logs\logs.plataformado\"
		Add-Content QsisPlataformar.bat "`r`ncd $global:script_pos\logs`r`n$QuiterInst\RepoWin\QSISpermisos.bat"
    }
	catch{
        a�adelog -message "No se pudo configurar QuiterSetup" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
		Write-Host -ForegroundColor Red "No se pudo configurar QuiterSetup"
		$FLAGS.errores.QuiterSetUp[0]++
    } 
	finally {a�adelog -message "Finalizada configuraci�n de QuiterSetup" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 3 Lanzar ejecuci�n de QsisPlataformar.bat
    try{
		a�adelog -message "Lanzanda ejecuci�n de QsisPlataformar.bat" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Set-Location $QuiterSetupDir\bin
        Start-Process QsisPlataformar.bat -Verbose -WindowStyle Minimized
        Write-Host ""
        Write-Host  -ForegroundColor Yellow "/!\ Lanzado cmd minimizado con la ejecuci�n de QsisPlataformar.bat /!\"
        Write-Host  -ForegroundColor Yellow "/!\ El cmd se cerrar� cuando finalice, el plataformado continua... /!\"
        Write-Host ""	    
        # Esperamos a que QuiterSetup pueble de contenido $QuiterDir antes de continuar
        sleep 10
    }
	catch{        
		a�adelog -message "No se pudo lanzar la ejecuci�n de QsisPlataformar.bat" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name    
		Write-Host -ForegroundColor Red "No se pudo lanzar la ejecuci�n de QsisPlataformar.bat" 
        $FLAGS.errores.QuiterSetUp[0]++   
    } 
	finally {a�adelog -message "Finaliza el lanzamiento de QsisPlataformar.bat" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "8/20 DESPLEGANDO QUITERSETUP" -msgtype "INFO " -func_name "end  "
}
function _Desplegar_WebPage_(){
    # 1 Creando directorio quiter_web
    # 2 Descomprimir p�ginas web 

    a�adelog -message "9/20 DESPLEGANDO PAGINAS WEB" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [9/20] Despliega P�ginas Web"
    Write-Host ""
    Set-Location $QuiterInst
	
    # 1 Creando directorio quiter_web
    $infmsg = "Creando directorio $QuiterDir\quiter_web"
    $errmsg = "�Atenci�n! No se pudo crear el directorio $QuiterDir\quiter_web"
    try{
	    a�adelog -message $infmsg -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		New-Item -ItemType directory -Path $QuiterDir\quiter_web|Out-Null
	}
	catch{ 
		a�adelog -message $errmsg -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red $errmsg
        $FLAGS.errores.QuiterWeb[0]++
	}
	finally{a�adelog -message "Finalizada creaci�n de $QuiterDir\quiter_web" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
        
    # 2 Decomprimir p�ginas web
	#   Despliega paginas web en funci�n de la varible $global:codigo_pais
    $pais = $PAISES[$global:codigo_pais].CodigoPais
    descomprime -origen $QuiterInst\paginas-$pais.zip -destino $QuiterDir\quiter_web -funcion $MyInvocation.MyCommand.Name
    	
    a�adelog -message "9/20 DESPLEGANDO PAGINAS WEB" -msgtype "INFO " -func_name "end  "

}
function _Instalar_QGateway_(){
    # 1 Descomprimir 
    # 2 Instalar
    # 3 Configurar Qjava
	# 4 Configurar MySql

    a�adelog -message "10/20 DESPLEGANDO QJAVA" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [10/20] Despliega Qjava"
    Write-Host ""
    Set-Location $QuiterInst
	$global:gatewaypass = if (!$global:gatewaypass) {"Gecnlsnd.$global:cod_cliente"} else {$global:gatewaypass}

    # 1 Descomprimir
    descomprime -origen $QuiterRepo\PaqueteQJavaWindows_64.zip -destino $QuiterDir -funcion $MyInvocation.MyCommand.Name
	#descomprime -origen $QuiterRepo\PaqueteQJavaWindows.zip -destino $QuiterDir -funcion $MyInvocation.MyCommand.Name
    
    # 2 Instalar
    try{
		a�adelog -message "Instalando Qjava" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Write-Host "Instalando Qjava"    
        Set-Location $QuiterDir\qjava\temp
		Start-Process -Wait $QuiterDir\qjava\temp\instalarQGWNuevo.bat
        # esperamos a que QGW despliegue carpeta conf y fichero.properties
		# esperamos a que QGW despliegue bbdd mysql
        sleep 60
    }
	catch{
        a�adelog -message "No se pudo instalar Qjava" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo instalar Qjava" 
		$FLAGS.errores.Qjava[0]++
    }
	finally{a�adelog -message "Finaliza instalaci�n Qjava" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    
    # 3 Configurar Qjava
    try{
		a�adelog -message "Configurando Qjava" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Write-Host "Configurando Qjava"    
        Write-Host "Deteniendo QuiterGateway"
        Stop-Service -Name quitergateway
        Copy-Item -Path $QuiterRepo\*.war -Destination $QuiterDir\qjava\apps\quitergateway\tomcat\webapps -Force
        $pais = $PAISES[$global:codigo_pais].string
        Set-Content $QuiterDir\qjava\apps\quitergateway\tomcat\bin\setenv.bat "set `"$pais`""
        #Write-Host $pais
        #Write-Host $global:gatewaypass
		Copy-Item -Path $QuiterDir\qjava\conf\quitergateway.properties -Destination $QuiterDir\qjava\conf\quitergateway.properties.bak
        Get-Content $QuiterDir\qjava\conf\quitergateway.properties   -raw | % {$_ -replace "password_universe=gateway", "password_universe=$global:gatewaypass"} | Set-Content $QuiterDir\qjava\conf\quitergateway.properties_1
        Get-Content $QuiterDir\qjava\conf\quitergateway.properties_1 -raw | % {$_ -replace "version_objetos_universe=10.2", "version_objetos_universe=11.3.2"} | Set-Content $QuiterDir\qjava\conf\quitergateway.properties_2
        Add-Content $QuiterDir\qjava\conf\quitergateway.properties_2 "dias_limite_estadisticas_pool=20"
		Add-Content $QuiterDir\qjava\conf\quitergateway.properties_2 "usuario_administrador=$global:username"
		Copy-Item -Path $QuiterDir\qjava\conf\quitergateway.properties_2 -Destination $QuiterDir\qjava\conf\quitergateway.properties
		Write-Host "Iniciando QuiterGateway"
        Start-Service -Name quitergateway
        Write-Host "Esperando QuiterGateway despliegue *.war"
        sleep 60
        Write-Host "Deteniendo QuiterGateway"
        Stop-Service -Name quitergateway
    }
	catch{
        a�adelog -message "No se pudo configurar Qjava" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo configurar Qjava" 
		$FLAGS.errores.Qjava[0]++
    }
	finally{a�adelog -message "Finaliza configuraci�n Qjava" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 4 Configurar MySql
    try{
		a�adelog -message "Configurando MySql" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Write-Host "Configurando MySql" 
        a�adelog -message "Configurando QsisMysqlCmd.txt" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        $MySqlCmd = New-Item -Path ("$global:script_pos\logs\QsisMysqlCmd___{0:yyyyMMdd_HHmmss}.txt" -f (Get-Date)) -ItemType File
		$MySqlLog = New-Item -Path ("$global:script_pos\logs\QsisMysqlLog___{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
		$MySqlExe = $QuiterDir+"\qjava\sys\mysql\bin\mysql.exe -u quiter --password=100495 <$MySqlCmd>$MySqlLog"
        Set-Content $MySqlCmd "SELECT * FROM quitergateway.licencias;"
		Add-Content $MySqlCmd "INSERT INTO quitergateway.licencias (``aplicacion``, ``licencias``) VALUES ('Conectividad', '2');"
		Add-Content $MySqlCmd "SELECT * FROM quitergateway.licencias;"
		cmd.exe /c $MySqlExe
        Write-Host "Reiniciando  MySql"
        Restart-Service -Name MySQL
		#Stop-Service -Name MySQL
    }
	catch{
        a�adelog -message "No se pudo configurar MySql" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo configurar MySql" 
		$FLAGS.errores.Qjava[0]++
    }
	finally{a�adelog -message "Finaliza configuraci�n MySql" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	
    a�adelog -message "10/20 DESPLEGANDO QJAVA" -msgtype "INFO " -func_name "end  "
}
function _InstalConfig__IIS_(){
    # 1 Instala y configura iis
	# 2 Test Ftp login

    a�adelog -message "11/20 INSTALAR/CONFIGURAR IIS" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [11/20] Instala/Configura IIS"
    Write-Host ""
    
    # 1 Instala y configura iis
    try{
		a�adelog -message "Instalar y Configurar IIS" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		#Set-Location $QuiterInst
        # Instalar IIS
        add-windowsfeature Web-Server, Web-Mgmt-Console, Web-Ftp-Server, Web-Ftp-Service
		Import-Module WebAdministration
        # Configurar IIS
		Set-ItemProperty "IIS:\Sites\Default Web Site" -Name physicalPath -Value $QuiterDir\quiter_web 
		New-WebVirtualDirectory -Site "Default Web Site" -Name "download" -PhysicalPath $QuiterUnit\InstalacionQuiterAutoWeb
		C:\windows\system32\inetsrv\appcmd.exe set config "Default Web Site/download" -section:system.webServer/directoryBrowse /enabled:"True" /showFlags:"Date, Time, Size, Extension"
		New-WebFtpSite -Name "QuiterFtp" -Port "21" -Force 
		Set-ItemProperty 'IIS:\Sites\QuiterFtp' -Name physicalPath -Value "C:\inetpub\ftproot" 
		Set-ItemProperty "IIS:\Sites\QuiterFtp" -Name ftpServer.security.ssl.controlChannelPolicy -Value 0 
		Set-ItemProperty "IIS:\Sites\QuiterFtp" -Name ftpServer.security.ssl.dataChannelPolicy -Value 0 
		Set-ItemProperty "IIS:\Sites\QuiterFtp" -Name ftpServer.security.authentication.basicAuthentication.enabled -Value $true 
		Add-WebConfiguration "/system.ftpServer/security/authorization" -value @{accessType="Allow";roles="";permissions=3;users="*"} -PSPath IIS:\ -location "QuiterFtp"
		New-Item 'IIS:\Sites\QuiterFtp\quiter' -type virtualdirectory -Physicalpath $QuiterDir
		New-Item 'IIS:\Sites\QuiterFtp\InstalacionQuiterAutoWeb' -type virtualdirectory -Physicalpath $QuiterUnit\InstalacionQuiterAutoWeb
		$prueba = "IIS:\Sites\QuiterFtp\"+$target
		New-Item $prueba -type virtualdirectory -Physicalpath $QuiterUnit
    }
	catch{
		a�adelog -message "No se pudo instalar/configurar IIS" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo instalar/configurar IIS"
		$FLAGS.errores.confIIS[0]++
    }
	finally{a�adelog -message "Finalizada instalaci�n y configuraci�n de IIS" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

	# 2 Test Ftp login
	try{
		a�adelog -message "Test Ftp login" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		$FtpLog = New-Item -Path ("$global:script_pos\logs\QsisFtpLog_____{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File
		$FtpErr = New-Item -Path ("$global:script_pos\logs\QsisFtpErr_____{0:yyyyMMdd_HHmmss}.err" -f (Get-Date)) -ItemType File
		#$Ftp = $global:FtpCmd
		#Si dejamos esto as� al instalar manualmente IIS no encuentra FtpCmd
		#Tenemos que utilizar el FtpCmd que genero la creacion de usuarios y que esta en logs
		$Ftp = (Get-ChildItem  $global:script_pos\logs\QsisFtpCmd_*.txt).fullname
		$FtpExe = "ftp.exe -v -i -d -s:$Ftp 1>$FtpLog 2>$FtpErr"
        cmd.exe /c "$FtpExe"
    }
	catch{
		a�adelog -message "No se pudo realizar Ftp test login" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo realizar Ftp test login"
		$FLAGS.errores.confIIS[0]++
    }
	finally{a�adelog -message "Finalizado Ftp test login" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

	a�adelog -message "11/20 INSTALAR/CONFIGURAR IIS" -msgtype "INFO " -func_name "end  "
	
}
function _Compartir_Dir_____(){
    # 1 Compartir DATOS
    # 2 Compartir INSQAEWEB
    # 3 Mostrar recursos compartidos
    
    a�adelog -message "12/20 COMPARTIR CARPETAS" -msgtype "INFO " -func_name "begin"
    Set-Location $QuiterInst
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [12/20] Compartir carpetas"
    Write-Host ""

    # 1 Compartir DATOS
    try{
		a�adelog -message "Compartir $QuiterDir\DATOS" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		New-SmbShare -Name "DATOS" -Path $QuiterDir\DATOS -FullAccess GQUITER
    }
	catch{
		a�adelog -message "No se pudo compartir $QuiterDir\DATOS" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
		Write-Host  -ForegroundColor Red "No se pudo compartir $QuiterDir\DATOS"
		$FLAGS.errores.CarpetasCompartidas[0]++
	}
	finally{a�adelog -message "Finalizado compartici�n de $QuiterDir\DATOS" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	
    # 2 Compartir INSQAWEB
    try{
		a�adelog -message "Compartir $QuiterUnit\InstalacionQuiterAutoWeb" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		New-SmbShare -Name INSQAWEB -Path $QuiterUnit\InstalacionQuiterAutoWeb -FullAccess GQUITER
    }
	catch{
		a�adelog -message "No se pudo compartir $QuiterUnit\InstalacionQuiterAutoWeb" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo compartir $QuiterUnit\InstalacionQuiterAutoWeb" 
		$FLAGS.errores.CarpetasCompartidas[0]++
    }
	finally{a�adelog -message "Finalizada compartici�n de $QuiterUnit\InstalacionQuiterAutoWeb" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

	# 3 Mostrar recursos compartidos
    #Get-SmbShare
    cmd /c $("net share")
        
	a�adelog -message "12/20 COMPARTIR CARPETAS" -msgtype "INFO " -func_name "end  "

} 
function _Desplegar_Qibk____(){
    # 1 Descomprimir QiBk
    # 2 Configuraci�n dependiendo de si existe R:
    # 3 A�adir tarea programada
    
    a�adelog -message "13/20 DESPLEGANDO QIBK" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [13/20] Desplegando QiBk"
    Write-Host ""
    Set-Location $QuiterInst

    # 1 Descomprimir QiBk
    descomprime -origen $QuiterRepo\Qibk.zip -destino $global:UvHome -funcion $MyInvocation.MyCommand.Name
    	
    # 2 Configuraci�n dependiendo de si existe R: 
    if(Test-Path -Path R:\){   
			a�adelog -message "Encontrada unidad R:\" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
	    try {
			a�adelog -message "Creando directorio R:\quiter_bk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
			New-Item -ItemType directory -Path R:\quiter_bk|Out-Null
		}
		catch{
			a�adelog -message "No se pudo crear R:\quiter_bk" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
			Write-Host -ForegroundColor Red "Existe R:\ pero no se ha podido crear R:\quiter_bk"
			$FLAGS.errores.Qibk[0]++
		}
		finally {a�adelog -message "Finalizada creaci�n del directorio R:\quiter_bk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
		
		try {
			a�adelog -message "Creando enlace simb�lico $QuiterUnit\quiter_bk a R:\quiter_bk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
            cmd /c mklink /D $QuiterUnit\quiter_bk R:\quiter_bk 
        }
		catch{
			a�adelog -message "No se pudo crear el enlace simbolico entre $QuiterUnit\quiter_bk y R:\quiter_bk" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
			Write-Host -ForegroundColor Red "No se pudo crear el enlace simbolico entre $QuiterUnit\quiter_bk y R:\quiter_bk" 
			$FLAGS.errores.Qibk[0]++
		}
		finally {a�adelog -message "Finalizada creaci�n del enlace simb�lico" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	}
	else{
		a�adelog -message "No existe R:\ sustituimos apuntamos donde est� desplegado Quiter" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		try{
			a�adelog -message "Creando directorio destino en $global:QuiterUnit\quiter_bk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name		
			New-Item -ItemType directory -Path $global:QuiterUnit\quiter_bk
		}
		catch {
			a�adelog -message "No se pudo crear el directorio $global:QuiterUnit\quiter_bk" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
			Write-Host  -ForegroundColor Red "No se pudo crear el directorio $global:QuiterUnit\quiter_bk"
			$FLAGS.errores.Qibk[0]++
		}
		finally {a�adelog -message "Finalizada creaci�n del directorio $global:QuiterUnit\quiter_bk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
     			
		try{
			$FilePath = $global:UvHome+'\qibk\conf_simple.xml'
            a�adelog -message "Modificar $FilePath para que apunte a $QuiterUnit\quiter_bk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
            Copy-Item -LiteralPath $FilePath -Destination $filePath'.bak'
			[xml]$XML = Get-Content $FilePath
			$value1= "$global:QuiterUnit\quiter_bk"
			$value2= "$global:QuiterDir"
    		$value=$XML.configuracion.copias.elementos.windows.destino.path = $value1
			$value=$XML.configuracion.copias.elementos.windows.origen.path = $value2
			$xml.save($FilePath)
			#
		}
		catch{
			a�adelog -message "No se pudo modificar conf_simple.xml" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
			Write-Host  -ForegroundColor Red "No se pudo modificar conf_simple.xml"
			$FLAGS.errores.Qibk[0]++
		}
		finally{a�adelog -message "Finalizada modificaci�n de conf_simple.xml" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    }
    
	# 3 A�adir tarea programada
    $infmsg = "Configurando tarea programada QiBk"
    $errmsg = "�Atenci�n! Tarea programada QiBk no agregada"
    try {
		a�adelog -message $infmsg -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	
	    $A=New-ScheduledTaskAction -Execute "$global:UvHome\qibk\qibk.bat"
        $T=New-ScheduledTaskTrigger -Daily -At 2:30am
        $U=New-ScheduledTaskPrincipal -UserId �$($env:USERDOMAIN)\$($env:USERNAME)� -LogonType S4U -RunLevel Highest
        $S=New-Scheduledtasksettingsset 
        $D=New-ScheduledTask -Action $A -Principal $U -Trigger $T -Settings $S
        Write-Host -ForegroundColor Yellow "Tarea Progamada QinternalBK"
		Register-ScheduledTask QinternalBK -InputObject $D -TaskPath "Quiter"
		
    }
	catch{
		a�adelog -message $errmsg -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red $errmsg
        $FLAGS.errores.Qibk[0]++
	}
	finally{a�adelog -message "Finalizada configuraci�n tarea programada QiBk" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	
    a�adelog -message "13/20 DESPLEGANDO QIBK" -msgtype "INFO " -func_name "end  "
}
function _Desplegar_QDBLive_(){
    # 1 Descomprimir QDBLive
    # 2 Configurar credenciales
    # 3 A�adir tarea programada
    # 4 Ejecutar QDBLive test credenciales

    a�adelog -message "14/20 DESPLEGANDO QDBLIVE" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [14/20] Desplegando QdbLive"
    Write-Host ""
    Set-Location $QuiterInst
		
    # 1 Descomprimir QDBlive
    descomprime -origen $QuiterRepo\QDBLiveWin.zip -destino $QuiterDir -funcion $MyInvocation.MyCommand.Name
    
	# 2 Configurar credenciales
    $infmsg = "Configurando credenciales en $QuiterDir\QDBLiveWin\u2dblivepy.conf"
    $errmsg = "�Atenci�n! Credenciales no almacenadas en $QuiterDir\QDBLiveWin\u2dblivepy.conf"
    try {
		#Write-Host $global:quiterpass
        a�adelog -message $infmsg  -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	
        Copy-Item -Path $QuiterDir\QDBLiveWin\u2dblivepy.conf -Destination $QuiterDir\QDBLiveWin\u2dblivepy.conf.bak 
        Get-Content $QuiterDir\QDBLiveWin\u2dblivepy.conf -raw | % {$_ -replace 'PASSWD="100495"', "PASSWD = `"$global:quiterpass`""} | Set-Content $QuiterDir\QDBLiveWin\u2dblivepy.conf.1 
        Copy-Item -Path $QuiterDir\QDBLiveWin\u2dblivepy.conf.1 -Destination $QuiterDir\QDBLiveWin\u2dblivepy.conf 
        Remove-Item $QuiterDir\QDBLiveWin\u2dblivepy.conf.1 
    }
	catch{
        a�adelog -message $errmsg -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red $errmsg
        $FLAGS.errores.Qdblive[0]++
	}
	finally{a�adelog -message "Finalizada configuraci�n de credenciales en QDBLive" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

	# 3 A�adir tarea programada
    $infmsg = "Configurando tarea programada QDBLive"
    $errmsg = "�Atenci�n! Tarea programada QDBlive no agregada"
    try {
        a�adelog -message $infmsg -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	
	    $A=New-ScheduledTaskAction -Execute $QuiterDir\QDBLiveWin\TaskQDBLiveWin.bat
        $triggers = @()
        $triggers += New-ScheduledTaskTrigger -Weekly -DaysOfWeek Saturday,Sunday -At 22:00pm
        $triggers += New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At 13:00pm
        $U=New-ScheduledTaskPrincipal -UserId �$($env:USERDOMAIN)\$($env:USERNAME)� -LogonType S4U -RunLevel Highest
        $S=New-Scheduledtasksettingsset 
        $D=New-ScheduledTask -Action $A -Principal $U -Trigger $triggers -Settings $S
		Write-Host -ForegroundColor Yellow "Tarea Progamada QDBLive"
		Register-ScheduledTask QDBLive -InputObject $D -TaskPath "Quiter"	
    }
	catch{
		a�adelog -message $errmsg -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red $errmsg
        $FLAGS.errores.Qdblive[0]++
	}
	finally{a�adelog -message "Finalizada configuraci�n tarea programada QDBLive" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	    
    # 4 Ejecutar QDBLive test credenciales
    $infmsg = "Ejecutando QDBLive para test credenciales"
    $errmsg = "�Atenci�n! Ejecuci�n QDBLiveWin erronea"
    try {
		#Write-Host $global:quiterpass
        a�adelog -message $infmsg  -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	
        Write-Host -ForegroundColor Yellow "Ejecutando QDBLive para test credenciales"
        Set-Location $QuiterDir\QDBLiveWin
        cmd /c QDBLiveWin.exe SMP -ac $QuiterDir\CONTA5 -f FTASCG 
    }
	catch{
        a�adelog -message $errmsg -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red $errmsg
        $FLAGS.errores.Qdblive[0]++
	}
	finally{a�adelog -message "Finalizada ejecuci�n QDBLiveWin" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "14/20 DESPLEGANDO QDBLIVE" -msgtype "INFO " -func_name "end  "
}
function _Desplegar_QawCli__(){
    # 1 Descomprimir instalador cliente QuiterAutoWeb
     
    a�adelog -message "15/20 DESPLEGANDO CLIENTE QUITERAUTOWEB" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [15/20] Desplegando QuiterAutoWeb"
    Write-Host ""
    Set-Location $QuiterInst

    descomprime -origen $QuiterRepo\InsQAW.zip -destino $QuiterUnit\InstalacionQuiterAutoWeb -funcion $MyInvocation.MyCommand.Name
    
    a�adelog -message "15/20 DESPLEGANDO CLIENTE QUITERAUTOWEB" -msgtype "INFO " -func_name "end  "
}
function _Configurar_Dir____(){
	# En el Qbase a veces viene QRS , IMPFILE o bin y otras no
	# Nos aseguramos que existan
	
    a�adelog -message "16/20 CONFIGURAR DIRECTORIOS ADICIONALES" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [16/20] Configurar directorios adicionales"
    Write-Host ""

    try{
		a�adelog -message "Configurando directorios adicionales" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	 
        Set-Location $QuiterDir
		check_dir -DirectoryToCreate $QuiterDir\QRS
		check_dir -DirectoryToCreate $QuiterDir\QRS\LOGOS
		check_dir -DirectoryToCreate $QuiterDir\QRS\IMPRESOS
		check_dir -DirectoryToCreate $QuiterDir\IMPFILE
		check_dir -DirectoryToCreate $QuiterDir\bin
    }
	catch{
   		a�adelog -message "Alg�n elemento/directorio no pudo ser eliminado [probablemente contin�a en uso]" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        Write-Host -ForegroundColor Red "Alg�n elemento/directorio no pudo ser eliminado [probablemente contin�a en uso]"
        $FLAGS.errores.Limpieza[0]++
    }
	finally{a�adelog -message "Finalizada configuracion directorios adicionales" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "16/20 CONFIGURAR DIRECTORIOS ADICIONALES" -msgtype "INFO " -func_name "end  "

}
function _Configurar_FireW__(){
	# 1 Deshabilita en el firewall la supervisi�n de nuestros interfaces vpn
	# 2 A�ade al firewall la regla QuiterAutoWeb
	    
    a�adelog -message "17/20 Configuraci�n Firewall" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [17/20] Configuraci�n Firewall"
    Write-Host ""
    	
    # 1 Deshabilita en el firewall la supervisi�n de nuestros interfaces vpn
    try {
		a�adelog -message "Deshabilitar supervisi�n interfaces vpn en firewall" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
        Write-Host -ForegroundColor Yellow "Deshabilitada supervisi�n interfaces vpn en firewall"
		Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "QuiterVpn", "Tun1000", "TunQis"
        Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "QuiterVpn", "Tun1000", "TunQis"
		Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "QuiterVpn", "Tun1000", "TunQis"
		$pais = $PAISES[$global:codigo_pais].CodigoPais
		switch($pais){
                "MX"{
						Write-Host "Dms Mexicano deshabilitar supervisi�n QuiterVpnMx y TunQisNa"
						Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "QuiterVpnMx", "TunQisNa"
						Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "QuiterVpnMx", "TunQisNa"
						Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "QuiterVpnMx", "TunQisNa"
                    }
                "CO"{
						Write-Host "Dms Colombiano deshabilitar supervisi�n TunQisLatam"
						Set-NetFirewallProfile -Name Public  -DisabledInterfaceAliases "TunQisLatam"
						Set-NetFirewallProfile -Name Private -DisabledInterfaceAliases "TunQisLatam"
						Set-NetFirewallProfile -Name Domain  -DisabledInterfaceAliases "TunQisLatam"
                    }
                default{
						Write-Host ""
                    }
        
		# Al hacerlo as� el FW pasa de verde a rojo porque no es la configuraci�n por defecto.
		# Estudiar la opci�n de a�adir reglas para conseguir lo mismo y que el FW contin�e en verde.
		
		}

	}
    catch{
   		a�adelog -message "Error al deshabilitar supervisi�n interfaces vpn en firewall" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        Write-Host -ForegroundColor Red "Error al deshabilitar supervisi�n interfaces vpn en firewall"
        $FLAGS.errores.FirewallConfig[0]++
    }
	finally{a�adelog -message "Deshabilitada supervisi�n interfaces vpn en firewall" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 2 A�ade al firewall la regla QuiterAutoWeb
    try {
		a�adelog -message "A�adir regla QuiterAutoWeb al firewall" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
		Write-Host -ForegroundColor Yellow "Agregada regla QuiterAutoWeb en firewall local."
		New-NetFirewallRule -DisplayName "QuiterAutoWeb" -Description "QuiterAutoWeb 31438, QGW 6080 y 6443" -Profile Private,Domain -Action Allow -Protocol TCP -LocalPort 31438, 6080, 6443 -Direction inbound
	}
    catch{
   		a�adelog -message "Error al a�adir regla QuiterAutoWeb al firewall" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        Write-Host -ForegroundColor Red "Error al a�adir regla QuiterAutoWeb al firewall"
        $FLAGS.errores.FirewallConfig[0]++
    }
	finally{a�adelog -message "A�adida regla QuiterAutoWeb al firewall" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "17/20 Configuraci�n Firewall" -msgtype "INFO " -func_name "end  "

}
function _DesActivarNetBios_(){
    # 1 Deshabilitar netbios sobre tcp-ip
	# Afecta a los interfaces de red activos, es decir que tienen direcci�n ip.
	# En el proceso de plataformado �nicamente afecta a la red local porque nuestras vpn no conectaron todav�a.
	# Una vez est�n conectadas todas nuestras vpn (todos los interfaces activos) ejecutar opci�n 21 desde el men� paso a paso para que repase todos los interfaces.
	    
    a�adelog -message "18/20 Deshabilitar Netbios sobre tcp/ip" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [18/20] Deshabilitar Netbios sobre tcp/ip"
    Write-Host ""

	# 1 Deshabilitar netbios sobre tcp-ip
	try{
	    a�adelog -message "Deshabilitar netbios sobre tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		# mostrar estado
		Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration' | Where-Object -Property 'TcpipNetbiosOptions' -ne $null | Select-Object -Property @('ServiceName', 'Description', 'TcpipNetbiosOptions');
		# modificar
		Write-Host -ForegroundColor Yellow "Deshabilitando Netbios"
		Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration' | Where-Object -Property 'TcpipNetbiosOptions' -ne $null | Invoke-CimMethod -MethodName 'SetTcpipNetbios' -Arguments @{ 'TcpipNetbiosOptions' = [UInt32](2) };
		# mostrar estado
		Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration' | Where-Object -Property 'TcpipNetbiosOptions' -ne $null | Select-Object -Property @('ServiceName', 'Description', 'TcpipNetbiosOptions');
    }
	catch{
		a�adelog -message "No se pudo deshabilitar netbios sobre tcp/ip" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo deshabilitar netbios sobre tcp/ip" 
		$FLAGS.errores.OpenVpn[0]++
    }
	finally{a�adelog -message "Finalizado Deshabilitar Netbios sobre tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
	
    a�adelog -message "18/20 Deshabilitar Netbios sobre tcp/ip" -msgtype "INFO " -func_name "end  "

}
function _Activar__RDesktop_(){
	# 1 Habilitar escritorio remoto
	
    a�adelog -message "19/20 HABILITAR ESCRITORIO REMOTO" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [19/20] Habilitar escritorio remoto"
    Write-Host ""

    try{
		a�adelog -message "Habilitar escritorio remoto" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	 
		Write-Host -ForegroundColor Yellow "Mostrar estado del escritorio remoto [fDenyTSConnections = 0 Habilitado Rdp]"
		Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections"
		Write-Host -ForegroundColor Yellow "Habilitar escritorio remoto [fDenyTSConnections = 0 Habilitado Rdp]"
		Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -value 0
		Write-Host -ForegroundColor Yellow "Habilitar regla en firewall para Rdp"
		Enable-NetFirewallRule -DisplayGroup "Escritorio Remoto"
		# Este instrucci�n s�lo funciona en sistema operativo en espa�ol y adem�s abre Rdp al perfil p�blico.
		# Intentamos evitar abrir nosotros Rdp en el perfil p�blico.
		# $FireWall = New-Object -comObject HNetCfg.FwPolicy2
		# $EnableRules = $FireWall.rules | Where-Object {$_.LocalPorts -like "*3389*" -and $_.Profiles -eq "3"}
		# ForEach ($Rule In $EnableRules){($Rule.Enabled = "True")}
		# Esto filtrar� las reglas y tomar� los nombres correctos de las reglas independientes del lenguaje.
		# Filtrando por el puerto 3389 y busca regla asociada con "Dominio y redes privadas".
		# Profiles -eq 3 es la m�scara de mapa de bits para redes privadas y de dominio.
		Write-Host -ForegroundColor Yellow "Mostrar estado del escritorio remoto [fDenyTSConnections = 0 Habilitado Rdp]"
		Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections"
    }
	catch{
   		a�adelog -message "No se pudo habilitar escritorio remoto." -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        Write-Host -ForegroundColor Red "No se pudo habilitar escritorio remoto."
    }
	finally{a�adelog -message "Finalizada configuracion escritorio remoto" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "19/20 HABILITAR ESCRITORIO REMOTO" -msgtype "INFO " -func_name "end  "

}
function _Limpieza_TmpFiles_(){
	# 1 Empaquetar logs
	# 2 Eliminar ficheros temporales
	
    a�adelog -message "20/20 LIMPIEZA" -msgtype "INFO " -func_name "begin"
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO [20/20] Limpieza"
    Write-Host ""

	# 1 Empaquetar logs
    # try{
		# a�adelog -message "Empaquetando logs" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	 
        # Set-Location $QuiterInst
		
		# # No podemos empaquetar los logs de Qsis_Dms_Installer porque est�n abiertos.
		# # Copiamos en otra carpeta, empaquetamos y en la parte de eliminaci�n de temporales los borra.
		# Copy-Item -Path $QuiterInst\Qsis_Dms_Installer\logs -Recurse $QuiterInst\Qsis_Dms_Installer\logs.qsis
		
		# # No podemos empaquetar los logs de QuiterSetup porque est�n abiertos.
		# # Copiamos en otra carpeta, empaquetamos y en la parte de eliminaci�n de temporales los borra.
		# Copy-Item -Path $global:QuiterSetupDir\logs -Recurse $global:QuiterSetupDir\logs.qsetup
		
		# # Empaquetar
		# #
		# # $global:QuiterSetupDir\logs         QuiterSetup        logs plataformado no podemos empaquetar porque contin�an en ejecucion
		# # $global:QuiterSetupDir\conf         QuiterSetUp        configuraci�n
		# # $QuiterInst\Qsis_Dms_Installer\logs Qsis_Dms_Installer logs              no podemos empaquetar porque contin�an en ejecucion
		# #
		# compress-archive -path $global:QuiterSetupDir\logs.qsetup,$global:QuiterSetupDir\conf,$QuiterInst\Qsis_Dms_Installer\logs.qsis $QuiterInst\Qsis_Dms_Installer_logs.zip -compressionlevel optimal
    # }
	# catch{
   		# a�adelog -message "Error al empaquetar logs" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        # Write-Host -ForegroundColor Red "Error al empaquetar logs"
        # $FLAGS.errores.Limpieza[0]++
    # }
	# finally{a�adelog -message "Finalizao empaquetar logs" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

	# 2 Eliminar ficheros temporales
    try{
		a�adelog -message "Realizando limpieza" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name	 
        Set-Location $QuiterInst
		Remove-Item $QuiterSetupDir\bin\*.log 
        Remove-Item $QuiterSetupDir\bin\*.log 
        Remove-Item $QuiterSetupDir\bin\*.sh 
        Remove-Item $QuiterInst\paginas*.zip 
        Remove-Item $QuiterInst\setup_plataforma.properties 
        Remove-Item -Recurse $QuiterSetupDir\jvm\jrelx
        Remove-Item -Recurse $QuiterSetupDir\bin\POSVENTA5
        Remove-Item -Recurse $QuiterInst\universe_11.3.*
        Remove-Item $QuiterInst\rclone.conf 
        Remove-Item $inst\Qsis_dms_installer\resources\usuarios.csv
		Remove-Item $QuiterDir\qjava\conf\quitergateway.properties_*
    }
	catch{
   		a�adelog -message "Alg�n elemento/directorio no pudo ser eliminado [probablemente contin�a en uso]" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        Write-Host -ForegroundColor Red "Alg�n elemento/directorio no pudo ser eliminado [probablemente contin�a en uso]"
        $FLAGS.errores.Limpieza[0]++
    }
	finally{a�adelog -message "Finalizada limpieza" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "20/20 LIMPIEZA" -msgtype "INFO " -func_name "end  "

}
function _Configurar_TunVpn_(){
    # 1 Cambia nuestros interfaces vpn del perfil p�blico al privado
	# NO puede incluirse en el proceso de plataformado (da error) porque los interfaces necesitan estar activos (tener ip)
	# para poder entran en el perfil y cambiarlo.
	# Cuando tenemos nuestas vpn conectadas, podemos ejecutar esta funci�n desde el men� paso a paso.
	  
    # 2 Deshabilitar netbios sobre tcp-ip
	# Afecta a los interfaces de red activos, es decir que tienen direcci�n ip.
	# En el proceso de plataformado �nicamente afecta a la red local porque nuestras vpn no conectaron todav�a.
	# Una vez est�n conectadas todas nuestras vpn (todos los interfaces activos) volvemos a ejecutar esta funci�n para que repase todos los interfaces.
	  
    a�adelog -message "Configurando interfaces Vpn" -msgtype "INFO " -func_name "begin"	
    Write-Host ""
    Write-Host -ForegroundColor Green $(Get-Date) "INFO Configurando interfaces Vpn"
    Write-Host ""
    	
    # 1 Cambia los interfaces vpn del perfil p�blico al privado
    try {
		Write-Host "Cambiando interfaces vpn de perfil"
		a�adelog -message "Cambiando interfaces vpn de perfil" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name 
		Get-NetConnectionProfile
		Get-NetConnectionProfile -InterfaceAlias "QuiterVpn" | Set-NetConnectionProfile -NetworkCategory Private
		Get-NetConnectionProfile -InterfaceAlias "Tun1000" | Set-NetConnectionProfile -NetworkCategory Private
		Get-NetConnectionProfile -InterfaceAlias "TunQis" | Set-NetConnectionProfile -NetworkCategory Private
		$pais = $PAISES[$global:codigo_pais].CodigoPais
		switch($pais){
                "MX"{
						Write-Host "Dms Mexicano QuiterVpnMx y TunQisNa"
						Get-NetConnectionProfile -InterfaceAlias "QuiterVpnMx" | Set-NetConnectionProfile -NetworkCategory Private
						Get-NetConnectionProfile -InterfaceAlias "TunQisNa" | Set-NetConnectionProfile -NetworkCategory Private
                    }
                "CO"{
						Write-Host "Dms Colombiano TunQisLatam"
						Get-NetConnectionProfile -InterfaceAlias "TunQisLatam" | Set-NetConnectionProfile -NetworkCategory Private
                    }
                default{
						Write-Host ""
                    }
        }
		Get-NetConnectionProfile
	}
    catch{
   		a�adelog -message "Error al cambiar interfaces vpn de perfil" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name	 
        Write-Host -ForegroundColor Red "Error al cambiar interfaces vpn de perfil"
        $FLAGS.errores.FirewallConfig[0]++
    }
	finally{a�adelog -message "Finalizado el cambio de perfil de los interfaces vpn" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

	# 2 Deshabilitar netbios sobre tcp/ip
	try{
	    a�adelog -message "Deshabilitar netbios sobre tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
		# mostrar estado
		Write-Host "Mostrar estado Netbios (0=habilitado)"
		Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration' | Where-Object -Property 'TcpipNetbiosOptions' -ne $null | Select-Object -Property @('ServiceName', 'Description', 'TcpipNetbiosOptions');
		# modificar
		Write-Host "Deshabilitando Netbios"
		Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration' | Where-Object -Property 'TcpipNetbiosOptions' -ne $null | Invoke-CimMethod -MethodName 'SetTcpipNetbios' -Arguments @{ 'TcpipNetbiosOptions' = [UInt32](2) };
		# mostrar estado
		Write-Host "Mostrar estado Netbios (2=deshabilitado)"
		Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration' | Where-Object -Property 'TcpipNetbiosOptions' -ne $null | Select-Object -Property @('ServiceName', 'Description', 'TcpipNetbiosOptions');
    }
	catch{
		a�adelog -message "No se pudo deshabilitar netbios sobre tcp/ip" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo deshabilitar netbios sobre tcp/ip" 
		$FLAGS.errores.OpenVpn[0]++
    }
	finally{a�adelog -message "Finalizado Deshabilitar Netbios sobre tcp/ip" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "Configurando interfaces Vpn" -msgtype "INFO " -func_name "end  "

}

#-- fin Funciones Principales

#-- Funciones Utilitarias

function testvar(){

   Write-Host""
   Write-Host " 1 [Drive system......: $target]"
   Write-Host " 2 [User QuiterSetup..: $global:username]"
   Write-Host " 3 [Pass Quitersetup..: $global:UnsecurePassword]"
   Write-Host " 4 [Dir UniVerse......: $UvHome]"
   Write-Host " 5 [Ver UniVerse......: $global:universe_ver]"
   Write-Host " 6 [Drive Quiter......: $QuiterUnit]"
   Write-Host " 7 [Dir Install.......: $QuiterInst]"
   Write-Host " 8 [Dir RepoWin.......: $QuiterRepo]"
   Write-Host " 9 [Dir QuiterSetup...: $QuiterSetupDir]"
   Write-Host "10 [Dir QS.Properties.: $QSetupDir]"
   Write-Host "11 [Codigo Cliente....: $global:cod_cliente]"
   Write-Host "12 [Codigo Pais.......: $global:codigo_pais]"
   Write-Host "13 [Direccion Ip......: $Diripv4]"
   Write-Host""

}
function verificar_admin (){
    # 1 Verificamos si PowerShell se inici� con privilegios de administrador
    # 2 Solicitamos credenciales para el proceso de instalaci�n con privilegios de admnistrador
    # 3 Almacenamos las credenciales facilitadas en texto plano para QuiterSetup        
	# 4 En funcion del idioma $PSUICulture asignamos los nombres de los grupos Usuarios y Operadores de impresion

    a�adelog -message "0/20 VERIFICANDO CREDENCIALES CON PRIVILEGIOS DE ADMINISTRADOR" -msgtype "INFO " -func_name "begin"

    # 1 Verificamos si PowerShell se inici� con privilegios de administrador        
    if([bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")){
                Write-Host "PowerShell iniciado con usuario elevado"
				$gadmins = ([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544').Translate( [System.Security.Principal.NTAccount]).Value
				$parts = $gadmins -split '\\'
                $global:AdmGroup = $parts[-1]
                #Write-Host $global:AdmGroup
    }
    else{
        Write-Host "PowerShell iniciado con usuario sin elevar"
        BREAK
    }
        
    # 2 Solicitamos credenciales para el proceso de instalaci�n con privilegios de admnistrador
    $Credential=$null
    while ($Credential -eq $null){
        #$Credential = Get-Credential -Username "$env:USERDNSDOMAIN\" -message "Introduce user/pass con privilegios de administrador"
        $Credential = Get-Credential -Username "administrador" -message "Introduce user/pass con privilegios de administrador"
        try{
            #Start-Process -FilePath cmd.exe /c -Credential $Credential
            a�adelog -message "Iniciado cmd con permisos elevados" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
            Start-Process powershell -Credential $Credential -WindowStyle Minimized -ArgumentList '-NoProfile -NonInteractive -command &{Start-Process cmd.exe /c -verb runas}'
            Write-Host "Credenciales facilitadas verificadas"
        }
        catch{
            $Credential=$null
            a�adelog -message "Las credenciales facilitadas NO tienen privilegios de administraci�n" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
            Write-Host -ForegroundColor Red "Las credenciales facilitadas NO tienen privilegios de administraci�n"
            BREAK
        }
        finally{a�adelog -message "Finalizada verificaci�n de credenciales con privilegios de administrador" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    }

    # 3 Almacenamos las credenciales facilitadas en texto plano para QuiterSetup
    $global:username = $Credential.GetNetworkCredential().username
    $global:UnsecurePassword = $Credential.GetNetworkCredential().password
    $global:identidad = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    #Write-Host $username
    #Write-Host $UnsecurePassword
	
	# 4 En funcion del idioma $PSCulture asignamos los nombres de los grupos Usuarios y Operadores de impresion
	# En servidor portugu�s, instalado en ingl�s y despu�s cambiado de regi�n, $PSCulture es pt-PT pero usuarios/grupos est�n en ingl�s.
    # switch($PSCulture){
            # pt-PT{
				# $global:UsrGroup = "Utilizadores"
				# $global:OpePrint = "Operadores de impress�o"						
			# }
            # es-ES{
				# $global:UsrGroup = "Usuarios"
				# $global:OpePrint = "Opers. de impresi�n"
			# }
            # es-MX{
				# $global:UsrGroup = "Usuarios"
				# $global:OpePrint = "Opers. de impresi�n"
			# }			
            # en-EN{
                # $global:UsrGroup = "Users"
                # $global:OpePrint = "Print Operators"
			# }
            # default{
				# Write-Host "Idioma no contemplado" -ForegroundColor Red
				# Write-Host $PSCulture
				# BREAK
			# }
    # }
	# Utilizamos $PSUICulture 
    switch($PSUICulture){
            pt-PT{
				$global:UsrGroup = "Utilizadores"
				$global:OpePrint = "Operadores de impress�o"						
			}
            es-ES{
				$global:UsrGroup = "Usuarios"
				$global:OpePrint = "Opers. de impresi�n"
			}
            es-MX{
				$global:UsrGroup = "Usuarios"
				$global:OpePrint = "Opers. de impresi�n"
			}			
            en-EN{
                $global:UsrGroup = "Users"
                $global:OpePrint = "Print Operators"
			}
            en-US{
                $global:UsrGroup = "Users"
                $global:OpePrint = "Print Operators"
			}
            default{
				Write-Host "Idioma no contemplado" -ForegroundColor Red
				Write-Host $PSCulture
				BREAK
			}
    }
	
    #Write-Host $global:UsrGroup
    #Write-Host $global:AdmGroup
    #Write-Host $global:OpePrint
	
    a�adelog -message "0/20 VERIFICANDO CREDENCIALES CON PRIVILEGIOS DE ADMINISTRADOR" -msgtype "INFO " -func_name "end  "
}
function revisa_permisos(){
    
    $existe = Test-Path -Path 'Q:\'
        
    # Comprobamos que la unidad existe, remplazar los destinos por las rutas 
    #dentro de una variable.

    if($existe -eq $false){

        Write-Host "NO EXISTE LA UNIDAD Q" -ForegroundColor Yellow
        $respuesta = Read-host "Quieres apuntar a otra unidad? [s/n] >_ "
        Write-Host "[INFO] - No esta implementado el chekeo de permisos en otra unidad todavia (da igual lo que respondas)"
        break
    }

    #Crafteamos las string para usarlas luego 

    $lista_dir = @("Q:\quiter","C:\uv\uv","Q:\InstalacionQuiterAutoWeb")
    $contiene = "$env:COMPUTERNAME\GQUITER"
        
    try{
		
        $dom = $env:USERDNSDOMAIN.Split('.')
        $contieneAD = $dom[0]+'\GQUITER'
       
    }

    catch{
        
        Write-host "No esta en un dominio"

    }


    #Permisos objetivo a evaluar despues
    ######################################

    $perm1 = "Write, Read, synchronize"
    $perm2 = "Write, ReadAndExecute, Synchronize" 
    $perm3 = "FullControl" 
    $condiArray = @($perm1, $perm2, $perm3)

    #lanzamos un bucle donde evaluamos todos los directorios
    # y varios tipos de permisos

    for($i = 0 ; $i -le $lista_dir.Count-1 ; $i++){
    
        #recoje los permisos de el directorio
        #obj en la iteracion en los que el grupo
        # GQUITER este presente

        $permission = (Get-Acl $lista_dir[$i]).Access |
        ?{$_.IdentityReference -match 'GQUITER'} |
        Select IdentityReference,FileSystemRights -Verbose


        #Si esta vacio preguntamos 
        # si lanzamos el script de permisos

        if($permission -eq $NULL) {
			
            Write-Host "ERROR EN PERMISOS en " $lista_dir[$i] -ForegroundColor Red
       
            $si = Read-Host("Lanzar QsisPermisos.bat [y/n] >_ ")
             
			if($si -eq 's'){
            
                qsis_permisos
            } 
                
        }
			 
        else{
     
            #En estos condicionales se evalua el nombre completo,
            # nombre del pc + grupo/usuario o dominio + grupo/usuario

            if($permission.IdentityReference -contains $contiene){ # identity para local
        
            #Testeamos permisos
                for($j = 0 ; $j -le $condiArray.Length ; $j++){
                
                    if($permission.FileSystemRights -eq $condiArray[$j]){

                         Write-Host  "Permisos del directorio"  $lista_dir[$i]  " correctos "
                         break

                     }
                }
              

            }elseif($permission.IdentityReference -contains $contieneAD){ #identity para active directory

                #Testeamos permisos
                for($j = 0 ; $j -le $condiArray.Length ; $j++){
               
                    if($permission.FileSystemRights -eq $condiArray[$j]){

                        Write-Host "Permisos del directorio"  $lista_dir[$i]  " correctos "
                        break
                    }
                }
            }
				
            else{
            
                Write-Host "Los permisos no estan bien establecidos en $lista_dir[$i]" -ForegroundColor red

            }
     
        }
    }
        
}
function a�adelog($message, $msgtype, $func_name){
    
    $LOG_DEBUG = ("{0:dd-MM-yyyy HH:mm:ss} [__TYPE__] [__FUNC__] [__MSG__]" -f (Get-Date))
    $LOG_DEBUG = $LOG_DEBUG -replace '__TYPE__',$msgtype
    $LOG_DEBUG = $LOG_DEBUG -replace '__MSG__',$message
    $LOG_DEBUG = $LOG_DEBUG -replace '__FUNC__',$func_name
    $LOG_DEBUG | Out-File $global:logname -Force -Append 
}
function descomprime($origen, $destino, $funcion){

    #Write-Host $origen
    #Write-Host $destino
    #Write-Host $funcion
    $infmsg = "Descomprimiendo $origen en $destino"
    $errmsg = "�Atenci�n! El archivo $origen no pudo ser descomprimido en $destino"			
    if(existe_comando -comando Expand-Archive){
	    try{
    	    a�adelog -message $infmsg -msgtype "INFO " -func_name $funcion
            Write-Host $infmsg
			Expand-Archive �LiteralPath $origen �DestinationPath $destino -Force
		}
		catch{
			a�adelog -message $errmsg -msgtype "ERROR" -func_name $funcion
            Write-Host -ForegroundColor Red $errmsg
		}
		finally{
            a�adelog -message "Descomprimido   $origen en $destino" -msgtype "INFO " -func_name $funcion
            Write-Host "Descomprimido   $origen en $destino"
        }
	}
	else{
		try{
			a�adelog -message $infmsg -msgtype "INFO " -func_name $funcion
            Write-Host $infmsg
            Write-Host "unzip propio"
            $shell = New-Object -ComObject Shell.Application
            $zipFile = $shell.NameSpace($origen)
            $destinationFolder = $shell.NameSpace($destino)
            $copyFlags = 0x00
            #$copyFlags += 0x04 # Hide progress dialogs
            $copyFlags += 0x10 # Overwrite existing files
            $destinationFolder.CopyHere($zipFile.Items(), $copyFlags)
		}
		catch{ 
            a�adelog -message $errmsg -msgtype "ERROR" -func_name $funcion	  
            Write-Host -ForegroundColor Red $errmsg
        }    
		finally{
            a�adelog -message "Descomprimido   $origen en $destino" -msgtype "INFO " -func_name $funcion
            Write-Host "Descomprimido   $origen en $destino"
        } 
	}
}
function existe_comando($comando){

    # -- 
    # Como en Windows2012 el CmdLet Expand-archive y algun otro no existen, esta funcion es una manera muy simple de que el codigo
    # de los script sea compatible con versiones antiguas de windws server y con versiones nuevas como Win2016
    # 
    # --
    
    if(Get-Command $comando -errorAction SilentlyContinue)
    {
        #Write-Host "$comando existe" -ForegroundColor Green
        return $true
    }
	else{
        #Write-Host "$comando no existe" -ForegroundColor Red
        return $false
		$FLAGS.errores.ExisteComando[0]++
    }
}
function pre_check(){
    # 1 Verificamos si la unidad donde queremos instalar existe
    # 2 Verificamos si existe la unidad Q
    # 3 Verificamos si existe la unidad R
    # 4 Verificamos si es Active Directory

    a�adelog -message "0/20 COMPROBACIONES PREVIAS" -msgtype "INFO " -func_name "begin"

    # 1 Verificamos si existe la unidad Q
    if (-not ( Test-Path -Path $global:QuiterUnit)){
        $FLAGS.errores.NoDiscos[0]++
        a�adelog -message "La unidad $global:QuiterUnit No existe o no est� disponible" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        # Si la unidad donde queremos deplegar no existe no podemos continuar
        Write-Host -ForegroundColor Yellow "La unidad $global:QuiterUnit no existe"
        pause
        $global:escierto = 0;return 0
    }
            
    # 2 Verificamos si existe la unidad Q
    if (-not ( Test-Path -Path "Q:\")){
        $FLAGS.errores.NoDiscos[0]++
        a�adelog -message "La unidad Q:\ No existe o no est� disponible" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        # Si la unidad Q no existe dejamos QiBk configurado donde est� deplegado Quiter, no es necesario consultar
        #Write-Host "La unidad Q:\ no existe �abortamos?"
        #$resp = Read-Host ">>>> Introduce opci�n [s/n] "
		#if($resp -eq 's'){$global:escierto = 0;return 0}
    }
        
    # 3 Verificamos si existe la unidad R
    if (-not ( Test-Path -Path "R:\")){
        $FLAGS.errores.NoDiscos[0]++
        a�adelog -message "La unidad R:\ No existe o no est� disponible" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        # Si la unidad R no existe dejamos QiBk configurado contra Q, no es necesario consultar
        #Write-Host "La unidad R:\ no existe �abortamos?"
        #$resp = Read-Host ">>>> Introduce opci�n [s/n] "
        #if($resp -eq 's'){$global:escierto = 0;return 0}
	}
    
    # 4 Verificamos si es Active Directory
    #Write-host " Nombre equipo : $env:COMPUTERNAME "
    if(existe_comando -comando Get-ADDomain){
        $FLAGS.errores.IsADEnable = "$true"
        $FLAGS.utils.IsADEnable = "$true"
        Write-Host "AD/LS...: ActiveDirectory"
    }else{
        Write-Host "AD/LS...: LocalServer"
    }
    
    a�adelog -message "0/20 COMPROBACIONES PREVIAS" -msgtype "INFO " -func_name "end  "
}
function add_tap(){
    
    $batfile = $global:script_pos + "\Add_tap.bat"
    $str_payload = '"C:\Program Files\TAP-Windows\bin\tapinstall.exe" install "C:\Program Files\TAP-Windows\driver\OemVista.inf" tap0901'

    $bat_payload = "@ echo off 
                     
                    $str_payload

                    rem $batfile

    
    
                    "
    
    Set-Content -Path $batfile -Value $bat_payload -Encoding ASCII
    
    Start-Process -FilePath $batfile 

}
function dar_parte(){

    # --
    # Falta que los errores se reporten a $flag_errors
    #
    <#
    Write-Host "ERRORES EN -> [Directorios] : " $flags_errors.


    Write-Host "ERRORES EN -> [Creaci�n de los directorios]:" $flags_errors.crear_dire
    Write-Host "ERRORES EN -> [Descarga del repositorio] :" $flags_errors.descarga_repo
    Write-Host "ERRORES EN -> [Existe comando]:" $flags_errors.existe_comando
    Write-Host "ERRORES EN -> [OpenVpn] :" $flags_errors.instalacion_OpenVpn
    Write-Host "ERRORES EN -> [Universe] :" $flags_errors.instalacion_universe
    Write-Host "ERRORES EN -> [Quiter Setup] :" $flags_errors.instalacion_quiter_setup
    Write-Host "ERRORES EN -> [Creacion usuarios] :" $flags_errors.crear_usuarios
    Write-Host "ERRORES EN -> [Creacion usuarios AD]:" $flags_errors.crear_usuarios_ad
    Write-Host "ERRORES EN -> [Despliegue web] :" $flags_errors.despliegue_web
    Write-Host "ERRORES EN -> [Despliegue Qjava]:" $flags_errors.despliegue_qjava
    Write-Host "ERRORES EN -> [Conf IIS] :" $flags_errors.desp_IIS
    Write-Host "ERRORES EN -> [Compartir carpetas] :" $flags_errors.comp_carpetas
    Write-Host "ERRORES EN -> [QIBK] :" $flags_errors.qibk
    Write-Host "ERRORES EN -> [QDBLive] :" $flags_errors.qdblive
    Write-Host "ERRORES EN -> [QAW] :" $flags_errors.QAW
    Write-Host "ERRORES EN -> [Firewall] :" $flags_errors.setup_rules
    Write-Host "ERRORES EN -> [La limpieza] :" $flags_errors.limpieza
    Write-Host "ERRORES EN -> [Firewall manual] :" $flags_errors.manual_rules
    #>
    Write-Host "    ______"
    Write-Host "___\errores\_______________________"
    $FLAGS.errores
    #Write-host "[ENTER]"
    #Read-host
	
}
function cuarenta_y_dos(){ 

      Write-host  ".............................................................................."
      Write-Host  " `Seis por nueve. Cuarenta y dos.� "
      Write-Host  " `Ya est�. Eso es todo lo que hay...� "
      Write-Host  " `Siempre pens� que hab�a algo fundamentalmente err�neo con este universo.� "
      Write-host  ".............................................................................."

}
function continua?(){
    
   Write-Host "� Continuar[s/n] ?"
   $sn = Read-Host ">_ :"
   if($sn -eq 'n'){
        return 0
		
   }
   
}
function recarga(){

    #Vuelve a recargar las rutas
    #ej: si el target se cambia de Q -> J se han de volver a cargar 
    #los paths para que todos tengan j
    
    $global:QuiterUnit = $target+':'
    $global:QuiterInst = $QuiterUnit + $inst
    $global:QuiterRepo = $QuiterInst+'\RepoWin'
    $global:QuiterSetupDir = $QuiterInst+'\quitersetup'
    $global:QuiterDir = $QuiterUnit+'\quiter'
    $global:QSetupQDir = $target+'\:\\quiter'
    $global:QSetupDir = $target+'\:\'+$inst+'\\quitersetup'
    $WIM_VERSION=gwmi win32_operatingsystem | % caption

}
function advise(){
    
    if($FLAGS.errores.IsADEnable -eq $true){
    
        Write-Host "SE RECOMIENDA QUE SE ELIJA LA OPCION DE INSTALACION EN ACTIVE DIRECTORY"
        Write-Host "IS AD ENABLE: " $FLAGS.errores.IsADEnable
        Write-Host "------------------------------------------------------------------------"
        Write-Host "Quieres lanzar la instalacion para Active directory?"
        $goAd = Read-Host "[s/n] >_ "


        if($goAd -eq 's'){
            
            corre_instalacion_AD

        }else{
        
            menu_instalacion
        }
           
    }

}
function cabecera(){

    $header = $PSScriptRoot + "\header.txt"     
    $text = Get-Content $header | Out-String    
    Write-Host $text                            

}
function comprobaciones(){
   
   <#
   Write-Host "Comprobando... archivo"
   Write-Host "................................................................"

   $filehash = Get-FileHash .\resources\Qsislib.psm1  -Algorithm SHA512 -Verbose 
   #$filehash.Hash | Out-File '.\resources\lib_hash.txt'
   $filehash_tocompare = Get-Content .\resources\lib_hash.txt
   
   if($filehash_tocompare -eq $filehash.Hash){
        
        Write-Host "Integridad del archivo ok [*]" -ForegroundColor Green
        sleep 3
   }else{
    
        exit
   
   }

   #>

    #comprueba si estamos en active directory y lo reporta


    #Checkea identidad
    Write-Host " Comprobando identidad..............[*]"
    Sleep 1
    $global:currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $global:identidad = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())

    

    if($identidad.Identities.Name -ne 'Administrador' -or 'Administrator'){
        
        Write-Host "Si no eres administrador algunas funcionalidades se podrian ver afectadas" -ForegroundColor Yellow
        
        Write-Host "Logeado como:" $currentPrincipal.Identity.Name
        Read-Host "---- [CONTINUAR] ----"
         
    }

    
}
function formulario(){
    
    # Si se ha de preguntar al usuario sobre el entorno 
    # en el que se encuentra al plataformar un server
    # seria preciso que fuera en esta funci�n, y asi agrupar info.

    # 1 Recoger informaci�n del c�digo de cliente
    # 2 Recoger informaci�n del pais
    a�adelog -message "0/20 CONSULTANDO CODIGO-CLIENTE PAIS VERSION-UV" -msgtype "INFO " -func_name "begin"

    # 1 Recoger informaci�n del c�digo de cliente
    try{
        a�adelog -message "Estableciendo c�digo de cliente" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        Write-Host "Para los usuarios standard a�adimos el c�digo de cliente en su contrase�a."
        $resp = 's'
        while ( $resp -eq 's' ) {
            Write-Host ">>>> Introduce c�digo de cliente [$global:cod_cliente]   : " -ForegroundColor Yellow -NoNewline
			$global:cod_cliente = if ($value = Read-Host) { $value } else { $global:cod_cliente } 
			Write-Output $global:cod_cliente | Out-File $QuiterInst\cod_cliente.txt
			if ( $cod_cliente -eq "" ) {
                $seclog = New-Item -Path ("logs\QsisSecPolicy__{0:yyyyMMdd_HHmmss}.log" -f (Get-Date)) -ItemType File #log sencillo 
                secedit /export /cfg $seclog |Out-Null
                if (@( Get-Content $seclog | Where-Object { $_.Contains("PasswordComplexity = 1") } ).Count -eq 1){
                    Write-Host -ForegroundColor Yellow "     La politica de complejidad de password esta activa"
                    Write-Host -ForegroundColor Yellow "     Las password de usuarios.csv deben cumplir la politica"
                    Write-Host -ForegroundColor Yellow "     �Volver a introducir codigo de cliente? "
                    $resp = Read-Host ">>>> Introduce opci�n [s/n] "
                }
                else{
                    $resp = 'n'
                }
            }
            else{
                $resp = 'n'
            }
        }
        #Write-Host "codigo cliente = $global:cod_cliente"
    }
	catch{
		a�adelog -message "No se estableci� c�dido de cliente" -msgtype "WARNI" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Yellow "     No se estableci� c�dido de cliente"
    }
	finally{a�adelog -message "Establecido   c�digo de cliente" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    # 2 Recoger informaci�n del pais
    try{
            a�adelog -message "Estableciendo c�digo de pa�s" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
            Write-Host "Para configuraciones necesitamos el c�digo de pa�s [ES,AR,PT,MX,CO,CL,BL,PE,ESAG,ARAG,PTAG]."
            Write-Host ">>>> Introduce c�digo de pa�s    [$global:codigo_pais]     : " -ForegroundColor Yellow -NoNewline
			$global:codigo_pais = if ($value = Read-Host) { $value } else { $global:codigo_pais }
						
            $result=switch("$global:codigo_pais"){
        
                ES {$PAISES.ES.selected = $true}
                ESAG {$PAISES.ESAG.selected = $true}
                AR {$PAISES.AR.selected = $true}
                ARAG {$PAISES.ARAG.selected = $true}
                PT {$PAISES.PT.selected = $true}
                PTAG {$PAISES.PTAG.selected = $true}
                MX {$PAISES.MX.selected = $true}
                CO {$PAISES.CO.selected = $true}
                CL {$PAISES.CL.selected = $true}
                BL {$PAISES.BL.selected = $true}
                PE {$PAISES.PE.selected = $true}
                default {$global:codigo_pais = "ES"}
            }
    }
    catch{
        a�adelog -message "No se pudo establecer el c�dido de pa�s" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo establecer el c�dido de pa�s"
    }
    finally{a�adelog -message "Establecido   c�digo de pa�s" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}
    
# 2 Recoger informaci�n de la version UniVerse que queremos instalar
    try{
            a�adelog -message "Estableciendo versi�n UniVerse" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
            Write-Host "Elige versi�n UniVerse a instalar [11.3.4 - 11.3.2 - 11.3.1]"
            Write-Host ">>>> Introduce versi�n UniVerse  [$global:universe_ver] : " -ForegroundColor Yellow -NoNewline
			$global:universe_ver = if ($value = Read-Host) { $value } else { $global:universe_ver }
    }
    catch{
        a�adelog -message "No se pudo establecer versi�n UniVerse a instalar" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
        Write-Host -ForegroundColor Red "No se pudo establecer versi�n UniVerse a instalar"
    }
    finally{a�adelog -message "Establecida   versi�n UniVerse" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name}

    a�adelog -message "0/20 CONSULTANDO CODIGO-CLIENTE PAIS VERSION-UV" -msgtype "INFO " -func_name "end  "  
}
function comprobaciones_finales(){

    $TargetProc = @("uv","uvsmm","uvcleanupd","uvservice","uvdlockd","")
    $TargetServ = @("unirpc","universe","uvtelnet")
    $servicios = Get-Service
    $procesos = Get-Process

}
function check_logs(){

    $ruta_logs_Qsetup = $global:QuiterSetupDir + "\logs\*.txt"
    $errores = Select-String -Path $ruta_logs_Qsetup -Pattern 'Error'  

    if($errores){
        
        Write-Host "ERRORES" $errores.Length

        foreach($i in $errores.Length ){
            
            Write-Host "$errores[$i]"
            Write-Host "--"
        }


    }else{
    
        Write-Host "No ERRORES en logs"
        
    }
	
    Sleep 8
}
function check_dir($DirectoryToCreate){
	if (-not (Test-Path -LiteralPath $DirectoryToCreate)) {
		
		try {
			#New-Item -Path $DirectoryToCreate -ItemType Directory -ErrorAction Stop | Out-Null #-Force
			New-Item -Path $DirectoryToCreate -ItemType Directory
		}
		catch {
			#Write-Error -Message "Unable to create directory '$DirectoryToCreate'. Error was: $_" -ErrorAction Stop
			Write-Error -Message "Error creando '$DirectoryToCreate'. Error was: $_"
		}
		"Creado '$DirectoryToCreate'."

	}
	else {
		"Direcotorio '$DirectoryToCreate' ya existe."
	}
}
function info_discos(){

        Write-Host "-----------------------------------------------------------------------------"
        Write-Host "Ubicacion del sistema en disco: (SYSDISK)"
        $disco_sys = Get-Disk | Where-Object IsSystem -eq $true
        Get-Partition -Disk $disco_sys
        Write-Host "-----------------------------------------------------------------------------"
        $discos = Get-Disk | Where-Object IsSystem -eq $false
        if($discos -ne $Null){
            for($i = 0 ; $i -le $discos.Length ; $i++){
                Get-Partition -Disk $discos[$i]            
            }
        }
}
function a�ade_reglas_fw($num_interfaz){
  
	a�adelog -message " A�ADIENDO LAS REGLAS AL FIREWALL" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name  
    
	try{
    
        New-NetFirewallRule -DisplayName "ALLOW QUITER TRAFFIC" -Action Allow  -Protocol TCP -InterfaceAlias $net_adapter[$num_interfaz].InterfaceAlias  -LocalPort 31438, 6080, 80, 6443, 139, 445, 20, 21 -Direction inbound -RemoteAddress 0.0.0.0 
        New-NetFirewallRule -DisplayName "ALLOW QUITER TRAFFIC" -Action Allow  -Protocol TCP -InterfaceAlias $net_adapter[$num_interfaz].InterfaceAlias  -LocalPort 31438, 6080, 80, 6443, 139, 445, 20, 21 -Direction outbound -RemoteAddress 0.0.0.0 
    }
	
	catch{
        
        a�adelog -message "ERROR A�ADIENDO LAS REGLAS AL FIREWALL" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
		$FLAGS.errores.ReglasFirewall
		
    }
}
function reglas_vpn([int]$interruptor){ #// [0 -> off] |  [1-> on]
    
     
    a�adelog -message " --------------------- APLICANDO REGLAS VPN -----------------------" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name

    if ($interruptor -eq 1){
        
        try{  
		 
			a�adelog -message "SE EMPIEZA A CONFIGURAR REGLAS EN EL FIREWALL" -msgtype "OK   " -func_name $MyInvocation.MyCommand.Name
            
			New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol UDP -InterfaceAlias QuiterVpn -LocalPort 80,443,1299,1195,2264 -Direction Outbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol UDP -InterfaceAlias QuiterVpn -LocalPort 80,443,1299,1195,2264 -Direction Inbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
    
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol UDP -InterfaceAlias Tun1000 -LocalPort 80,443,1299,1195,2264 -Direction Outbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol UDP -InterfaceAlias Tun1000 -LocalPort 80,443,1299,1195,2264 -Direction Inbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162

			New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol UDP -InterfaceAlias TunQis -LocalPort 80,443,1299,1195,2264 -Direction Outbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol UDP -InterfaceAlias TunQis -LocalPort 80,443,1299,1195,2264 -Direction Inbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
			
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol TCP -InterfaceAlias QuiterVpn -LocalPort 80,443,1299,1195,2264 -Direction Outbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol TCP -InterfaceAlias QuiterVpn -LocalPort 80,443,1299,1195,2264 -Direction Inbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162

            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol TCP -InterfaceAlias Tun1000 -LocalPort 80,443,1299,1195,2264 -Direction Outbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol TCP -InterfaceAlias Tun1000 -LocalPort 80,443,1299,1195,2264 -Direction Inbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162

            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol TCP -InterfaceAlias TunQis -LocalPort 80,443,1299,1195,2264 -Direction Outbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162
            New-NetFirewallRule -DisplayName "Permite trafico quiter VPN" -Action Allow  -Protocol TCP -InterfaceAlias TunQis -LocalPort 80,443,1299,1195,2264 -Direction Inbound -RemoteAddress 95.39.37.37, 82.223.75.136, 213.201.90.162

        }
		
		catch{
		
			a�adelog -message "No se ha podido a�adir al firewall la conf base" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
            Write-Host "No se ha podido a�adir al firewall la conf base"
			$FLAGS.errores.ReglasFirewall[0]++
        
		}
		
		finally{ 
		
			a�adelog -message "SE FINALIZA LA CONFIGURACI�N DE LAS REGLAS EN EL FIREWALL" -msgtype "OK   " -func_name $MyInvocation.MyCommand.Name 
		
		}

    }
	
	else{
	
		try {
		
			a�adelog -message "ELIMINANDO REGLAS" -msgtype "OK   " -func_name $MyInvocation.MyCommand.Name
            
			Remove-NetFirewallRule -DisplayName "Permite trafico quiter VPN"
			a�adelog -message "Reglas eliminadas, configuracino quitada :c" -msgtype "OK   " -func_name $MyInvocation.MyCommand.Name
        
		}
		
		catch{
		
			a�adelog -message "No se pudo eliminar las reglas del Firewall" -msgtype "ERROR" -func_name $MyInvocation.MyCommand.Name
			$FLAGS.errores.ReglasFirewall
		}
		
		finally{ 
		 
			a�adelog -message "FIN DE LA CONFIGURACI�N DE LAS REGLAS DEL FIREWALL" -msgtype "OK   " -func_name $MyInvocation.MyCommand.Name
		 
		 }
    }

    a�adelog -message " --------------------- REGLAS VPN APLICADAS-----------------------" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
        
} 
function add_regla(){

    a�adelog -message " --------------------- APLICANDO REGLAS MANUALES -----------------------" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
            
    $PROTO = "TCP"
    $PORTS = "0-65535"
    $IPADD = "0.0.0.0"
    $DNAME = "Quiter Net ManualRule"
    $DIRECCION = "Outbound"
    $ACCION = "allow"

    $escierto = 1
    while($escierto){

        Write-host "-------------------"
        Write-Host "/1/DEFAULT" $PROTO
        Write-Host "/2/DEFAULT" $PORTS
        Write-Host "/3/DEFAULT" $IPADD
        Write-Host "/4/DEFAULT" $DNAME
        Write-Host "/5/DEFAULT" $DIRECCION
        Write-Host "/6/DEFAULT" $ACCION
        Write-Host "/7/ [EXECUTE RULE]"
        Write-Host "/8/ SALIR"
         Write-host "-------------------"
        $opcion = Read-Host ">_ "
        $nuevo_val = Read-Host "Nuevo valor >_ "

        switch($opcion){
        
            1{$PROTO = $nuevo_val}
            2{$PORTS = $nuevo_val}
            3{$IPADD = $nuevo_val}
            4{$DNAME = $nuevo_val}
            5{$DIRECCION = $nuevo_val}
            6{$ACCION = $nuevo_val}
            7{New-NetFirewallRule -DisplayName $DNAMe -Action $ACCION  -Protocol $PROTO -LocalPort $PORTS -Direction $DIRECCION -RemoteAddress $IPADD}
            8{$escierto = 0 ; break}

        }
    
    }

    a�adelog -message " --------------------- REGLAS MANUALES APLICADAS  -----------------------" -msgtype "INFO " -func_name $MyInvocation.MyCommand.Name
   
}

#-- fin Funciones Utilitarias

a�adelog -message "FUNCIONES CARGADAS" -msgtype "INFO "
a�adelog -message "LIBRERIA  CARGADA"  -msgtype "INFO "

#exportamos todas las varibales y funciones
Export-ModuleMember -Function * -Variable * 
